import React, { useState, useEffect } from 'react';
import { Container, Row, Col, Card, ProgressBar, Button, Badge, Alert } from 'react-bootstrap';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';

const Dashboard = () => {
    const { user, loading: authLoading } = useAuth();
    const [userProgress, setUserProgress] = useState(null);
    const [userEnrollments, setUserEnrollments] = useState([]);
    const [dataLoading, setDataLoading] = useState(true);
    const [error, setError] = useState('');
    const navigate = useNavigate();

    useEffect(() => {
        // Wait for auth to finish loading
        if (authLoading) {
            return;
        }

        // If no user after auth check, redirect to login
        if (!user) {
            navigate('/login');
            return;
        }

        // If user exists, fetch dashboard data
        fetchUserData();
    }, [user, authLoading, navigate]);

    const fetchUserData = async () => {
        try {
            setDataLoading(true);
            setError('');
            
            console.log('🔄 Fetching data for user:', user.id);
            
            // Fetch user progress with user ID from AuthContext
            const progressResponse = await axios.get(`http://localhost:5000/api/user/progress?userId=${user.id}`);
            console.log('📊 Progress data:', progressResponse.data);
            setUserProgress(progressResponse.data);
            
            // Fetch user enrollments with user ID from AuthContext
            const enrollmentsResponse = await axios.get(`http://localhost:5000/api/user/enrollments?userId=${user.id}`);
            console.log('📋 Enrollments data:', enrollmentsResponse.data);
            setUserEnrollments(enrollmentsResponse.data.enrollments || []);
            
        } catch (error) {
            console.error('❌ Error fetching user data:', error);
            setError('Failed to load dashboard data. Please try again.');
            // Fallback data for new users
            setUserProgress({
                enrolled_courses: 0,
                completed_courses: 0,
                learning_time: "0h 0m",
                current_streak: 0,
                in_progress_courses: 0,
                not_started_courses: 0
            });
            setUserEnrollments([]);
        } finally {
            setDataLoading(false);
        }
    };

    const markAsCompleted = async (courseId) => {
        try {
            await axios.post('http://localhost:5000/api/user/complete-course', {
                userId: user.id,
                courseId: courseId
            });
            fetchUserData(); // Refresh data
        } catch (error) {
            console.error('Error marking course as completed:', error);
            setError('Failed to mark course as completed.');
        }
    };

    const updateProgress = async (courseId, progress) => {
        try {
            await axios.post('http://localhost:5000/api/user/update-progress', {
                userId: user.id,
                courseId: courseId,
                progress: progress
            });
            fetchUserData(); // Refresh data
        } catch (error) {
            console.error('Error updating progress:', error);
            setError('Failed to update progress.');
        }
    };

    // Show loading while checking authentication OR loading data
    if (authLoading || dataLoading) {
        return (
            <Container className="py-5" style={{ marginTop: '76px' }}>
                <div className="text-center py-5">
                    <div className="spinner-border text-primary" role="status">
                        <span className="visually-hidden">Loading...</span>
                    </div>
                    <p className="mt-3 text-muted">
                        {authLoading ? 'Checking authentication...' : 'Loading your dashboard...'}
                    </p>
                </div>
            </Container>
        );
    }

    // If no user (should not happen due to redirect, but just in case)
    if (!user) {
        return (
            <Container className="py-5" style={{ marginTop: '76px' }}>
                <div className="text-center py-5">
                    <Alert variant="warning">
                        <i className="fas fa-exclamation-triangle me-2"></i>
                        Please login to access your dashboard.
                    </Alert>
                    <Button as={Link} to="/login" variant="primary">
                        Go to Login
                    </Button>
                </div>
            </Container>
        );
    }

    return (
        <Container className="py-5" style={{ marginTop: '76px' }}>
            {/* Error Alert */}
            {error && (
                <Alert variant="danger" className="mb-4">
                    <i className="fas fa-exclamation-triangle me-2"></i>
                    {error}
                </Alert>
            )}

            {/* Welcome Section */}
            <Row className="mb-5">
                <Col>
                    <Card className="border-0 stats-card text-white">
                        <Card.Body className="p-5">
                            <Row className="align-items-center">
                                <Col md={8}>
                                    <h1 className="display-6 fw-bold mb-3">
                                        Welcome back, {user.name}! 👋
                                    </h1>
                                    <p className="lead mb-0">
                                        {userProgress?.enrolled_courses === 0 
                                            ? "Start your learning journey today!" 
                                            : `You have ${userProgress?.enrolled_courses} enrolled courses`
                                        }
                                    </p>
                                </Col>
                                <Col md={4} className="text-center">
                                    <div className="display-4 fw-bold">{userProgress?.current_streak || 0}</div>
                                    <small>Day Learning Streak 🔥</small>
                                </Col>
                            </Row>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>

            {/* Stats Cards */}
            <Row className="mb-5">
                <Col md={3} className="mb-4">
                    <Card className="card-hover text-center border-0">
                        <Card.Body className="p-4">
                            <div className="text-primary mb-3">
                                <i className="fas fa-book-open fa-2x"></i>
                            </div>
                            <h3 className="fw-bold text-dark">{userProgress?.enrolled_courses || 0}</h3>
                            <p className="text-muted mb-0">Enrolled Courses</p>
                        </Card.Body>
                    </Card>
                </Col>
                <Col md={3} className="mb-4">
                    <Card className="card-hover text-center border-0">
                        <Card.Body className="p-4">
                            <div className="text-success mb-3">
                                <i className="fas fa-trophy fa-2x"></i>
                            </div>
                            <h3 className="fw-bold text-dark">{userProgress?.completed_courses || 0}</h3>
                            <p className="text-muted mb-0">Completed</p>
                        </Card.Body>
                    </Card>
                </Col>
                <Col md={3} className="mb-4">
                    <Card className="card-hover text-center border-0">
                        <Card.Body className="p-4">
                            <div className="text-warning mb-3">
                                <i className="fas fa-clock fa-2x"></i>
                            </div>
                            <h3 className="fw-bold text-dark">{userProgress?.learning_time || '0h 0m'}</h3>
                            <p className="text-muted mb-0">Learning Time</p>
                        </Card.Body>
                    </Card>
                </Col>
                <Col md={3} className="mb-4">
                    <Card className="card-hover text-center border-0">
                        <Card.Body className="p-4">
                            <div className="text-info mb-3">
                                <i className="fas fa-chart-line fa-2x"></i>
                            </div>
                            <h3 className="fw-bold text-dark">
                                {userProgress?.enrolled_courses > 0 
                                    ? `${Math.round((userProgress.completed_courses / userProgress.enrolled_courses) * 100)}%`
                                    : '0%'
                                }
                            </h3>
                            <p className="text-muted mb-0">Completion Rate</p>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>

            {/* My Courses Section */}
            <Row>
                <Col lg={8}>
                    <Card className="border-0 card-hover">
                        <Card.Body className="p-4">
                            <div className="d-flex justify-content-between align-items-center mb-4">
                                <h4 className="fw-bold mb-0 text-dark">My Courses</h4>
                                <Button as={Link} to="/courses" variant="outline-primary" size="sm">
                                    Browse More Courses
                                </Button>
                            </div>
                            
                            {userEnrollments.length > 0 ? (
                                userEnrollments.map(enrollment => (
                                    <div key={enrollment.id} className="border-bottom pb-3 mb-3">
                                        <Row className="align-items-center">
                                            <Col md={8}>
                                                <div className="d-flex justify-content-between align-items-start mb-2">
                                                    <h6 className="fw-bold mb-1 text-dark">{enrollment.course?.title || 'Course'}</h6>
                                                    <Badge 
                                                        bg={enrollment.completed ? "success" : "primary"}
                                                        className="ms-2"
                                                    >
                                                        {enrollment.completed ? "Completed" : `${enrollment.progress}%`}
                                                    </Badge>
                                                </div>
                                                <p className="text-muted small mb-2">
                                                    {enrollment.course?.description?.substring(0, 100) || 'Course description...'}...
                                                </p>
                                                <div className="d-flex align-items-center">
                                                    <ProgressBar 
                                                        now={enrollment.progress} 
                                                        style={{ width: '150px', height: '8px' }} 
                                                        className="me-3" 
                                                        variant={enrollment.completed ? "success" : "primary"}
                                                    />
                                                    <small className="text-muted">
                                                        {enrollment.completed ? 'Completed' : `${enrollment.progress}% Complete`}
                                                    </small>
                                                </div>
                                                <small className="text-muted">
                                                    Enrolled: {new Date(enrollment.enrolledAt).toLocaleDateString()}
                                                </small>
                                            </Col>
                                            <Col md={4} className="text-end">
                                                <div className="d-flex flex-column gap-2">
                                                    <Button 
                                                        as={Link} 
                                                        to={`/course/${enrollment.courseId}`}
                                                        variant="primary" 
                                                        size="sm"
                                                    >
                                                        {enrollment.completed ? 'Review' : 'Continue'}
                                                    </Button>
                                                    {!enrollment.completed && (
                                                        <div className="d-flex gap-1">
                                                            <Button 
                                                                variant="outline-success" 
                                                                size="sm"
                                                                onClick={() => updateProgress(enrollment.courseId, enrollment.progress + 25)}
                                                                disabled={enrollment.progress >= 100}
                                                            >
                                                                +25%
                                                            </Button>
                                                            <Button 
                                                                variant="outline-warning" 
                                                                size="sm"
                                                                onClick={() => markAsCompleted(enrollment.courseId)}
                                                            >
                                                                Complete
                                                            </Button>
                                                        </div>
                                                    )}
                                                </div>
                                            </Col>
                                        </Row>
                                    </div>
                                ))
                            ) : (
                                <div className="text-center py-4">
                                    <i className="fas fa-book-open fa-2x text-muted mb-3"></i>
                                    <h5 className="text-muted">No courses enrolled yet</h5>
                                    <p className="text-muted mb-3">Start your learning journey by enrolling in a course</p>
                                    <Button as={Link} to="/courses" variant="primary" size="lg">
                                        <i className="fas fa-search me-2"></i>
                                        Browse Courses
                                    </Button>
                                </div>
                            )}
                        </Card.Body>
                    </Card>
                </Col>

                {/* Sidebar */}
                <Col lg={4}>
                    {/* Learning Progress */}
                    <Card className="border-0 card-hover mb-4">
                        <Card.Body className="p-4">
                            <h6 className="fw-bold mb-3 text-dark">Learning Progress</h6>
                            <div className="text-center mb-3">
                                <div className="display-6 fw-bold text-primary">
                                    {userProgress?.enrolled_courses || 0}
                                </div>
                                <small className="text-muted">Total Enrolled Courses</small>
                            </div>
                            <div className="mb-3">
                                <div className="d-flex justify-content-between small text-muted mb-1">
                                    <span>Completed</span>
                                    <span>{userProgress?.completed_courses || 0}</span>
                                </div>
                                <ProgressBar 
                                    now={userProgress?.enrolled_courses > 0 
                                        ? (userProgress.completed_courses / userProgress.enrolled_courses) * 100 
                                        : 0
                                    } 
                                    variant="success"
                                    className="mb-2" 
                                />
                            </div>
                            <div className="mb-3">
                                <div className="d-flex justify-content-between small text-muted mb-1">
                                    <span>In Progress</span>
                                    <span>{userProgress?.in_progress_courses || 0}</span>
                                </div>
                                <ProgressBar 
                                    now={userProgress?.enrolled_courses > 0 
                                        ? (userProgress.in_progress_courses / userProgress.enrolled_courses) * 100 
                                        : 0
                                    } 
                                    variant="warning"
                                    className="mb-2" 
                                />
                            </div>
                            <div>
                                <div className="d-flex justify-content-between small text-muted mb-1">
                                    <span>Not Started</span>
                                    <span>{userProgress?.not_started_courses || 0}</span>
                                </div>
                                <ProgressBar 
                                    now={userProgress?.enrolled_courses > 0 
                                        ? (userProgress.not_started_courses / userProgress.enrolled_courses) * 100 
                                        : 0
                                    } 
                                    variant="secondary"
                                />
                            </div>
                        </Card.Body>
                    </Card>

                    {/* Quick Actions */}
                    <Card className="border-0 card-hover">
                        <Card.Body className="p-4">
                            <h6 className="fw-bold mb-3 text-dark">Quick Actions</h6>
                            <div className="d-grid gap-2">
                                <Button variant="outline-primary" as={Link} to="/courses">
                                    <i className="fas fa-search me-2"></i>
                                    Browse Courses
                                </Button>
                                <Button variant="outline-success" as={Link} to="/courses">
                                    <i className="fas fa-plus me-2"></i>
                                    Enroll New Course
                                </Button>
                                {userEnrollments.length > 0 && (
                                    <Button variant="outline-warning" as={Link} to="/courses">
                                        <i className="fas fa-sync me-2"></i>
                                        Continue Learning
                                    </Button>
                                )}
                                <Button variant="outline-info">
                                    <i className="fas fa-question-circle me-2"></i>
                                    Get Help
                                </Button>
                            </div>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>

            {/* Motivation Section for New Users */}
            {userProgress?.enrolled_courses === 0 && (
                <Row className="mt-5">
                    <Col>
                        <Card className="border-0 bg-light">
                            <Card.Body className="text-center p-5">
                                <div className="text-primary mb-3">
                                    <i className="fas fa-graduation-cap fa-3x"></i>
                                </div>
                                <h4 className="fw-bold text-dark mb-3">Start Your Learning Journey Today!</h4>
                                <p className="text-muted mb-4">
                                    Join thousands of students who are advancing their careers with our courses. 
                                    Choose from 24+ professional courses and start learning at your own pace.
                                </p>
                                <Button as={Link} to="/courses" variant="primary" size="lg">
                                    <i className="fas fa-rocket me-2"></i>
                                    Explore Courses
                                </Button>
                            </Card.Body>
                        </Card>
                    </Col>
                </Row>
            )}
        </Container>
    );
};

export default Dashboard;