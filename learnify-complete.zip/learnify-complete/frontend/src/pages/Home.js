import React from 'react';
import { Container, Row, Col, Button, Card } from 'react-bootstrap';
import { Link, useNavigate } from 'react-router-dom';
import HeroSection from '../components/Home/HeroSection';
import FeaturesSection from '../components/Home/FeaturesSection';
import CourseGrid from '../components/Courses/CourseGrid';

const Home = () => {
    const navigate = useNavigate();

    const handleCategoryClick = (categoryName) => {
        navigate('/courses', { 
            state: { selectedCategory: categoryName }
        });
    };

    const categories = [
        { name: 'Development', icon: 'fas fa-code', count: '7 Courses', color: 'primary' },
        { name: 'Data Science', icon: 'fas fa-chart-line', count: '2 Courses', color: 'success' },
        { name: 'Design', icon: 'fas fa-palette', count: '4 Courses', color: 'warning' },
        { name: 'Marketing', icon: 'fas fa-bullhorn', count: '3 Courses', color: 'info' },
        { name: 'Business', icon: 'fas fa-briefcase', count: '2 Courses', color: 'secondary' },
        { name: 'Cloud & DevOps', icon: 'fas fa-cloud', count: '2 Courses', color: 'dark' }
    ];

    return (
        <div>
            <HeroSection />
            <FeaturesSection />
            
            {/* Popular Courses Section */}
            <section className="py-5 bg-white">
                <Container>
                    <Row className="text-center mb-5">
                        <Col>
                            <h2 className="display-5 fw-bold gradient-text mb-3">Popular Courses</h2>
                            <p className="lead text-muted">Start learning with our most popular courses</p>
                        </Col>
                    </Row>
                    <CourseGrid limit={12} />
                    <Row className="mt-4">
                        <Col className="text-center">
                            <Button 
                                as={Link} 
                                to="/courses" 
                                variant="outline-primary" 
                                size="lg"
                                className="px-5"
                            >
                                <i className="fas fa-book me-2"></i>
                                View All Courses
                            </Button>
                        </Col>
                    </Row>
                </Container>
            </section>

            {/* Categories Section */}
            <section className="py-5 bg-light">
                <Container>
                    <Row className="text-center mb-5">
                        <Col>
                            <h2 className="display-5 fw-bold gradient-text mb-3">Explore Categories</h2>
                            <p className="lead text-muted">Find courses in your area of interest</p>
                        </Col>
                    </Row>
                    <Row>
                        {categories.map((category, index) => (
                            <Col lg={4} md={6} key={index} className="mb-4">
                                <Card 
                                    className="border-0 card-hover h-100 text-center p-4 bg-light"
                                    role="button"
                                    onClick={() => handleCategoryClick(category.name.split(' & ')[0])} // Handle compound names
                                    style={{ cursor: 'pointer', transition: 'all 0.3s ease' }}
                                >
                                    <Card.Body>
                                        <div className={`text-${category.color} mb-3`}>
                                            <i className={`${category.icon} fa-3x`}></i>
                                        </div>
                                        <h5 className="card-title fw-bold">{category.name}</h5>
                                        <p className="card-text text-muted">{category.count}</p>
                                        <Button 
                                            variant="outline-primary" 
                                            size="sm"
                                        >
                                            Explore
                                        </Button>
                                    </Card.Body>
                                </Card>
                            </Col>
                        ))}
                    </Row>
                </Container>
            </section>

            {/* Stats Section */}
            <section className="py-5 bg-primary text-white">
                <Container>
                    <Row className="text-center">
                        <Col lg={3} md={6} className="mb-4">
                            <div className="display-4 fw-bold">24+</div>
                            <p className="mb-0">Courses Available</p>
                        </Col>
                        <Col lg={3} md={6} className="mb-4">
                            <div className="display-4 fw-bold">10K+</div>
                            <p className="mb-0">Students Enrolled</p>
                        </Col>
                        <Col lg={3} md={6} className="mb-4">
                            <div className="display-4 fw-bold">15+</div>
                            <p className="mb-0">Expert Instructors</p>
                        </Col>
                        <Col lg={3} md={6} className="mb-4">
                            <div className="display-4 fw-bold">4.7</div>
                            <p className="mb-0">Average Rating</p>
                        </Col>
                    </Row>
                </Container>
            </section>

            {/* CTA Section */}
            <section className="py-5 bg-dark text-white">
                <Container>
                    <Row className="align-items-center">
                        <Col lg={8}>
                            <h3 className="fw-bold mb-3">Ready to start your learning journey?</h3>
                            <p className="lead mb-0">Join thousands of students who are advancing their careers with our courses.</p>
                        </Col>
                        <Col lg={4} className="text-lg-end">
                            <Button 
                                as={Link} 
                                to="/register" 
                                variant="warning" 
                                size="lg"
                                className="fw-semibold"
                            >
                                <i className="fas fa-rocket me-2"></i>
                                Get Started Today
                            </Button>
                        </Col>
                    </Row>
                </Container>
            </section>
        </div>
    );
};

export default Home;