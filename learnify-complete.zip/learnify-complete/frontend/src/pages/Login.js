import React, { useState } from 'react';
import { Container, Row, Col, Card, Form, Button, Alert, Spinner } from 'react-bootstrap';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';

const Login = () => {
    const [formData, setFormData] = useState({
        email: '',
        password: ''
    });
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');
    const navigate = useNavigate();
    const { login } = useAuth();

    const handleChange = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value
        });
        if (error) setError('');
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        setError('');

        // Basic validation
        if (!formData.email || !formData.password) {
            setError('Please fill in all fields');
            setLoading(false);
            return;
        }

        try {
            console.log('Login attempt with:', formData.email);
            
            const response = await axios.post('http://localhost:5000/api/auth/login', formData);
            
            console.log('Login successful:', response.data.user.name);
            
            if (response.data.success) {
                // Use AuthContext login function
                login(response.data.user);
                
                // Show success message
                alert(`Login successful! Welcome back, ${response.data.user.name}`);
                
                // Redirect to dashboard
                navigate('/dashboard');
            }
        } catch (err) {
            console.error('Login error:', err);
            if (err.response) {
                setError(err.response.data.error || 'Invalid email or password');
            } else if (err.request) {
                setError('Cannot connect to server. Please check if backend is running.');
            } else {
                setError('An unexpected error occurred. Please try again.');
            }
        } finally {
            setLoading(false);
        }
    };

    // Demo accounts for testing
    const demoAccounts = [
        { email: 'john@example.com', password: 'password123', name: 'John Doe' },
        { email: 'sarah@example.com', password: 'password123', name: 'Sarah Johnson' }
    ];

    const fillDemoAccount = (account) => {
        setFormData({
            email: account.email,
            password: account.password
        });
    };

    return (
        <Container fluid className="bg-light min-vh-100 d-flex align-items-center" style={{ paddingTop: '76px' }}>
            <Row className="w-100 justify-content-center">
                <Col md={6} lg={4}>
                    <Card className="shadow border-0">
                        <Card.Body className="p-5">
                            <div className="text-center mb-4">
                                <h2 className="fw-bold gradient-text">Welcome Back</h2>
                                <p className="text-muted">Sign in to your account</p>
                            </div>

                            {error && (
                                <Alert variant="danger">
                                    <i className="fas fa-exclamation-triangle me-2"></i>
                                    {error}
                                </Alert>
                            )}

                            <Form onSubmit={handleSubmit}>
                                <Form.Group className="mb-3">
                                    <Form.Label>Email Address</Form.Label>
                                    <Form.Control
                                        type="email"
                                        name="email"
                                        value={formData.email}
                                        onChange={handleChange}
                                        placeholder="Enter your email"
                                        required
                                        disabled={loading}
                                    />
                                </Form.Group>

                                <Form.Group className="mb-4">
                                    <Form.Label>Password</Form.Label>
                                    <Form.Control
                                        type="password"
                                        name="password"
                                        value={formData.password}
                                        onChange={handleChange}
                                        placeholder="Enter your password"
                                        required
                                        disabled={loading}
                                    />
                                </Form.Group>

                                <Button 
                                    variant="primary" 
                                    type="submit" 
                                    className="w-100 py-2 fw-semibold"
                                    disabled={loading}
                                >
                                    {loading ? (
                                        <>
                                            <Spinner
                                                as="span"
                                                animation="border"
                                                size="sm"
                                                role="status"
                                                aria-hidden="true"
                                                className="me-2"
                                            />
                                            Signing In...
                                        </>
                                    ) : (
                                        <>
                                            <i className="fas fa-sign-in-alt me-2"></i>
                                            Sign In
                                        </>
                                    )}
                                </Button>
                            </Form>

                            {/* Demo Accounts */}
                            <div className="mt-4">
                                <h6 className="text-center text-muted mb-3">Demo Accounts (Click to fill)</h6>
                                <div className="d-grid gap-2">
                                    {demoAccounts.map((account, index) => (
                                        <Button
                                            key={index}
                                            variant="outline-secondary"
                                            size="sm"
                                            onClick={() => fillDemoAccount(account)}
                                            disabled={loading}
                                        >
                                            {account.name} - {account.email}
                                        </Button>
                                    ))}
                                </div>
                            </div>

                            <div className="text-center mt-4">
                                <p className="text-muted">
                                    Don't have an account?{' '}
                                    <Link to="/register" className="text-primary text-decoration-none fw-semibold">
                                        Sign up here
                                    </Link>
                                </p>
                            </div>

                            <div className="text-center mt-3">
                                <small className="text-muted">
                                    After registration, come back here to login
                                </small>
                            </div>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>
        </Container>
    );
};

export default Login;