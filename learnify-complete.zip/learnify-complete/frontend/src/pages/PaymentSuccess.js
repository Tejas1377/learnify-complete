import React, { useEffect, useState } from 'react';
import { Container, Row, Col, Card, Button, Alert } from 'react-bootstrap';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import axios from 'axios';

const PaymentSuccess = () => {
    const location = useLocation();
    const navigate = useNavigate();
    const [enrollmentData, setEnrollmentData] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        // Simulate loading enrollment data
        setTimeout(() => {
            const data = location.state?.enrollmentData || {
                enrollmentId: `enroll_${Date.now()}`,
                courseId: location.state?.course?.id || 1,
                courseTitle: location.state?.course?.title || "Web Development Masterclass",
                date: new Date().toLocaleDateString(),
                message: "Payment successful! Course enrolled successfully."
            };
            
            setEnrollmentData(data);
            setLoading(false);
        }, 1500);
    }, [location]);

    if (loading) {
        return (
            <Container className="py-5" style={{ marginTop: '76px' }}>
                <div className="text-center py-5">
                    <div className="spinner-border text-primary" style={{ width: '3rem', height: '3rem' }} role="status">
                        <span className="visually-hidden">Loading...</span>
                    </div>
                    <p className="mt-3 text-muted">Loading your enrollment details...</p>
                </div>
            </Container>
        );
    }

    return (
        <Container className="py-5" style={{ marginTop: '76px' }}>
            <Row className="justify-content-center">
                <Col lg={8}>
                    <Card className="border-0 shadow-sm text-center">
                        <Card.Body className="p-5">
                            <div className="text-success mb-4">
                                <i className="fas fa-check-circle fa-5x"></i>
                            </div>
                            
                            <h1 className="display-4 fw-bold text-success mb-3">
                                Payment Successful!
                            </h1>
                            
                            <p className="lead text-muted mb-4">
                                Thank you for your purchase! You are now enrolled in the course.
                            </p>

                            {enrollmentData && (
                                <Alert variant="success" className="text-start">
                                    <h5 className="mb-3">
                                        <i className="fas fa-graduation-cap me-2"></i>
                                        Enrollment Details
                                    </h5>
                                    <div className="row">
                                        <div className="col-md-6">
                                            <p><strong>Course:</strong> {enrollmentData.courseTitle}</p>
                                            <p><strong>Enrollment ID:</strong> {enrollmentData.enrollmentId}</p>
                                        </div>
                                        <div className="col-md-6">
                                            <p><strong>Date:</strong> {enrollmentData.date}</p>
                                            <p><strong>Status:</strong> <span className="text-success">Active</span></p>
                                        </div>
                                    </div>
                                    <p className="mb-0 mt-2">
                                        <i className="fas fa-envelope me-2"></i>
                                        A confirmation email has been sent to your registered email address.
                                    </p>
                                </Alert>
                            )}

                            <div className="d-flex gap-3 justify-content-center flex-wrap mt-4">
                                <Button 
                                    as={Link} 
                                    to="/courses" 
                                    variant="outline-primary" 
                                    size="lg"
                                >
                                    <i className="fas fa-book me-2"></i>
                                    Browse More Courses
                                </Button>
                                
                                <Button 
                                    as={Link} 
                                    to="/" 
                                    variant="primary" 
                                    size="lg"
                                >
                                    <i className="fas fa-home me-2"></i>
                                    Go to Home
                                </Button>
                                
                                <Button 
                                    as={Link} 
                                    to={`/course/${enrollmentData?.courseId}`}
                                    variant="success" 
                                    size="lg"
                                >
                                    <i className="fas fa-play-circle me-2"></i>
                                    Start Learning
                                </Button>
                            </div>

                            <div className="mt-5 pt-4 border-top">
                                <h5 className="mb-4">What's Next?</h5>
                                <div className="row text-start">
                                    <div className="col-md-4 mb-3">
                                        <div className="text-center p-3">
                                            <div className="text-primary mb-3">
                                                <i className="fas fa-video fa-2x"></i>
                                            </div>
                                            <h6>Access Course Content</h6>
                                            <p className="small text-muted mb-0">
                                                Start watching videos and complete assignments at your own pace.
                                            </p>
                                        </div>
                                    </div>
                                    <div className="col-md-4 mb-3">
                                        <div className="text-center p-3">
                                            <div className="text-success mb-3">
                                                <i className="fas fa-download fa-2x"></i>
                                            </div>
                                            <h6>Download Resources</h6>
                                            <p className="small text-muted mb-0">
                                                Get all course materials, code files, and resources.
                                            </p>
                                        </div>
                                    </div>
                                    <div className="col-md-4 mb-3">
                                        <div className="text-center p-3">
                                            <div className="text-warning mb-3">
                                                <i className="fas fa-certificate fa-2x"></i>
                                            </div>
                                            <h6>Get Certificate</h6>
                                            <p className="small text-muted mb-0">
                                                Complete the course to receive your certificate of completion.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div className="mt-4 pt-3 border-top">
                                <p className="text-muted small">
                                    <i className="fas fa-question-circle me-1"></i>
                                    Need help? Contact our support team at support@learnify.com
                                </p>
                            </div>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>
        </Container>
    );
};

export default PaymentSuccess;