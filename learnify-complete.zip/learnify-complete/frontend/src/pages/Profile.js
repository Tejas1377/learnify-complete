// Replace the entire Profile component with this:

import React from 'react';
import { Container, Row, Col, Card, Form, Button, Tab, Tabs, ProgressBar, Badge } from 'react-bootstrap';

const Profile = () => {
    const user = JSON.parse(localStorage.getItem('user')) || {
        name: 'Guest User',
        email: 'guest@example.com',
        avatar: 'https://ui-avatars.com/api/?name=Guest+User&background=6366f1&color=fff'
    };

    const enrolledCourses = [
        { id: 1, title: 'Web Development Masterclass', progress: 65 },
        { id: 2, title: 'Data Science Fundamentals', progress: 30 },
        { id: 3, title: 'Mobile App Development', progress: 85 }
    ];

    const handleProfileUpdate = (e) => {
        e.preventDefault();
        alert('Profile updated successfully!');
    };

    return (
        <Container className="py-5" style={{ marginTop: '76px' }}>
            <Row>
                <Col lg={4} className="mb-4">
                    <Card className="border-0 card-hover text-center">
                        <Card.Body className="p-4">
                            <div className="mb-4">
                                <img 
                                    src={user.avatar} 
                                    alt="Profile" 
                                    className="rounded-circle mb-3"
                                    style={{ width: '120px', height: '120px', objectFit: 'cover' }}
                                />
                                <h4 className="fw-bold">{user.name}</h4>
                                <p className="text-muted">{user.email}</p>
                                <Badge bg="primary">Pro Member</Badge>
                            </div>

                            <div className="border-top pt-3">
                                <div className="row text-center">
                                    <div className="col-4">
                                        <div className="fw-bold">12</div>
                                        <small className="text-muted">Courses</small>
                                    </div>
                                    <div className="col-4">
                                        <div className="fw-bold">45h</div>
                                        <small className="text-muted">Learned</small>
                                    </div>
                                    <div className="col-4">
                                        <div className="fw-bold">8</div>
                                        <small className="text-muted">Certificates</small>
                                    </div>
                                </div>
                            </div>
                        </Card.Body>
                    </Card>
                </Col>

                <Col lg={8}>
                    <Card className="border-0 card-hover">
                        <Card.Body>
                            <Tabs defaultActiveKey="profile" className="mb-3">
                                <Tab eventKey="profile" title="Profile Settings">
                                    <Form onSubmit={handleProfileUpdate}>
                                        <Row>
                                            <Col md={6}>
                                                <Form.Group className="mb-3">
                                                    <Form.Label>Full Name</Form.Label>
                                                    <Form.Control 
                                                        type="text" 
                                                        defaultValue={user.name}
                                                    />
                                                </Form.Group>
                                            </Col>
                                            <Col md={6}>
                                                <Form.Group className="mb-3">
                                                    <Form.Label>Email</Form.Label>
                                                    <Form.Control 
                                                        type="email" 
                                                        defaultValue={user.email}
                                                    />
                                                </Form.Group>
                                            </Col>
                                        </Row>
                                        <Form.Group className="mb-3">
                                            <Form.Label>Bio</Form.Label>
                                            <Form.Control 
                                                as="textarea" 
                                                rows={3}
                                                placeholder="Tell us about yourself..."
                                                defaultValue="Passionate learner focused on web development and data science."
                                            />
                                        </Form.Group>
                                        <Button variant="primary" type="submit">Update Profile</Button>
                                    </Form>
                                </Tab>

                                <Tab eventKey="courses" title="My Courses">
                                    <h6 className="fw-bold mb-3">Enrolled Courses</h6>
                                    {enrolledCourses.map(course => (
                                        <div key={course.id} className="border-bottom pb-3 mb-3">
                                            <div className="d-flex justify-content-between align-items-center mb-2">
                                                <h6 className="mb-0">{course.title}</h6>
                                                <Badge bg="primary">{course.progress}%</Badge>
                                            </div>
                                            <ProgressBar now={course.progress} className="mb-2" />
                                            <div className="d-flex justify-content-between">
                                                <small className="text-muted">Last accessed: 2 days ago</small>
                                                <Button variant="outline-primary" size="sm">
                                                    Continue
                                                </Button>
                                            </div>
                                        </div>
                                    ))}
                                </Tab>

                                <Tab eventKey="achievements" title="Achievements">
                                    <Row>
                                        <Col md={6} className="mb-3">
                                            <Card className="border-0 bg-light">
                                                <Card.Body className="text-center">
                                                    <i className="fas fa-medal fa-2x text-warning mb-2"></i>
                                                    <h6>Fast Learner</h6>
                                                    <small className="text-muted">Complete 5 courses in a month</small>
                                                </Card.Body>
                                            </Card>
                                        </Col>
                                        <Col md={6} className="mb-3">
                                            <Card className="border-0 bg-light">
                                                <Card.Body className="text-center">
                                                    <i className="fas fa-fire fa-2x text-danger mb-2"></i>
                                                    <h6>7-Day Streak</h6>
                                                    <small className="text-muted">Learn for 7 consecutive days</small>
                                                </Card.Body>
                                            </Card>
                                        </Col>
                                        <Col md={6} className="mb-3">
                                            <Card className="border-0 bg-light">
                                                <Card.Body className="text-center">
                                                    <i className="fas fa-star fa-2x text-success mb-2"></i>
                                                    <h6>Top Student</h6>
                                                    <small className="text-muted">Achieve 90%+ in all courses</small>
                                                </Card.Body>
                                            </Card>
                                        </Col>
                                    </Row>
                                </Tab>
                            </Tabs>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>
        </Container>
    );
};

export default Profile;