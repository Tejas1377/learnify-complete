import React, { useState } from 'react';
import { Container, Row, Col, Card, Form, Button, Alert, Spinner } from 'react-bootstrap';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';

const Register = () => {
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        password: '',
        confirmPassword: ''
    });
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');
    const [success, setSuccess] = useState('');
    const navigate = useNavigate();

    const handleChange = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value
        });
        if (error) setError('');
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        setError('');
        setSuccess('');

        // Validation
        if (!formData.name || !formData.email || !formData.password || !formData.confirmPassword) {
            setError('All fields are required');
            setLoading(false);
            return;
        }

        if (formData.password !== formData.confirmPassword) {
            setError('Passwords do not match');
            setLoading(false);
            return;
        }

        if (formData.password.length < 6) {
            setError('Password must be at least 6 characters long');
            setLoading(false);
            return;
        }

        try {
            const response = await axios.post('http://localhost:5000/api/auth/register', {
                name: formData.name,
                email: formData.email,
                password: formData.password
            });

            console.log('Registration response:', response.data);

            if (response.data.success) {
                setSuccess('Registration successful! Redirecting to login page...');
                
                // CHANGED: Redirect to login page after 2 seconds
                setTimeout(() => {
                    navigate('/login');
                }, 2000);
            }
        } catch (err) {
            console.error('Registration error:', err);
            if (err.response) {
                setError(err.response.data.error || 'Registration failed. Please try again.');
            } else if (err.request) {
                setError('Cannot connect to server. Please check if backend is running on port 5000.');
            } else {
                setError('An unexpected error occurred. Please try again.');
            }
        } finally {
            setLoading(false);
        }
    };

    const testRegistration = () => {
        setFormData({
            name: 'Tejas Pawar',
            email: `tejas${Date.now()}@example.com`,
            password: 'password123',
            confirmPassword: 'password123'
        });
    };

    return (
        <Container fluid className="bg-light min-vh-100 d-flex align-items-center" style={{ paddingTop: '76px' }}>
            <Row className="w-100 justify-content-center">
                <Col md={6} lg={5}>
                    <Card className="shadow border-0">
                        <Card.Body className="p-5">
                            <div className="text-center mb-4">
                                <h2 className="fw-bold gradient-text">Create Account</h2>
                                <p className="text-muted">Join thousands of learners today</p>
                            </div>

                            {error && (
                                <Alert variant="danger">
                                    <i className="fas fa-exclamation-triangle me-2"></i>
                                    {error}
                                </Alert>
                            )}

                            {success && (
                                <Alert variant="success">
                                    <i className="fas fa-check-circle me-2"></i>
                                    {success}
                                </Alert>
                            )}

                            <Form onSubmit={handleSubmit}>
                                <Form.Group className="mb-3">
                                    <Form.Label className="fw-semibold">Full Name</Form.Label>
                                    <Form.Control
                                        type="text"
                                        name="name"
                                        value={formData.name}
                                        onChange={handleChange}
                                        placeholder="Enter your full name"
                                        required
                                        disabled={loading}
                                    />
                                </Form.Group>

                                <Form.Group className="mb-3">
                                    <Form.Label className="fw-semibold">Email Address</Form.Label>
                                    <Form.Control
                                        type="email"
                                        name="email"
                                        value={formData.email}
                                        onChange={handleChange}
                                        placeholder="Enter your email"
                                        required
                                        disabled={loading}
                                    />
                                </Form.Group>

                                <Form.Group className="mb-3">
                                    <Form.Label className="fw-semibold">Password</Form.Label>
                                    <Form.Control
                                        type="password"
                                        name="password"
                                        value={formData.password}
                                        onChange={handleChange}
                                        placeholder="Create a password (min. 6 characters)"
                                        required
                                        disabled={loading}
                                    />
                                    <Form.Text className="text-muted">
                                        Must be at least 6 characters long
                                    </Form.Text>
                                </Form.Group>

                                <Form.Group className="mb-4">
                                    <Form.Label className="fw-semibold">Confirm Password</Form.Label>
                                    <Form.Control
                                        type="password"
                                        name="confirmPassword"
                                        value={formData.confirmPassword}
                                        onChange={handleChange}
                                        placeholder="Confirm your password"
                                        required
                                        disabled={loading}
                                    />
                                </Form.Group>

                                <Button 
                                    variant="primary" 
                                    type="submit" 
                                    className="w-100 py-2 fw-semibold"
                                    disabled={loading}
                                    size="lg"
                                >
                                    {loading ? (
                                        <>
                                            <Spinner
                                                as="span"
                                                animation="border"
                                                size="sm"
                                                role="status"
                                                aria-hidden="true"
                                                className="me-2"
                                            />
                                            Creating Account...
                                        </>
                                    ) : (
                                        <>
                                            <i className="fas fa-user-plus me-2"></i>
                                            Create Account
                                        </>
                                    )}
                                </Button>
                            </Form>

                            <div className="text-center mt-3">
                                <Button 
                                    variant="outline-secondary" 
                                    size="sm" 
                                    onClick={testRegistration}
                                    disabled={loading}
                                >
                                    <i className="fas fa-vial me-2"></i>
                                    Fill Test Data
                                </Button>
                            </div>

                            <div className="text-center mt-4">
                                <p className="text-muted">
                                    Already have an account?{' '}
                                    <Link to="/login" className="text-primary text-decoration-none fw-semibold">
                                        Sign in here
                                    </Link>
                                </p>
                            </div>

                            <div className="text-center mt-3">
                                <small className="text-muted">
                                    By registering, you agree to our Terms of Service and Privacy Policy
                                </small>
                            </div>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>
        </Container>
    );
};

export default Register;