import React, { useState, useEffect } from 'react';
import { Container, Row, Col, Button, Card, Badge, ListGroup, Alert } from 'react-bootstrap';
import { useParams, Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import PaymentModal from '../components/Payment/PaymentModal';

const CourseDetail = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const [course, setCourse] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [showPaymentModal, setShowPaymentModal] = useState(false);

    useEffect(() => {
        console.log('🆔 Course ID from URL:', id, 'Type:', typeof id);
        fetchCourseDetails();
    }, [id]);

    const fetchCourseDetails = async () => {
        try {
            setLoading(true);
            setError(null);
            
            console.log('🔍 Fetching course details for ID:', id);
            
            // Check if ID is valid
            if (!id || isNaN(parseInt(id))) {
                setError('Invalid course ID');
                setLoading(false);
                return;
            }
            
            const response = await axios.get(`http://localhost:5000/api/courses/${id}`);
            console.log('✅ Course data received:', response.data);
            setCourse(response.data);
            
        } catch (error) {
            console.error('❌ Error fetching course details:', error);
            console.error('❌ Error response:', error.response);
            
            if (error.response?.status === 404) {
                setError('Course not found. The course ID might be invalid.');
            } else if (error.response?.status === 400) {
                setError('Invalid course ID format.');
            } else {
                setError('Failed to load course details. Please try again.');
            }
        } finally {
            setLoading(false);
        }
    };

    const handleEnrollClick = () => {
        setShowPaymentModal(true);
    };

    const handlePaymentSuccess = (paymentData) => {
        console.log('Payment successful:', paymentData);
        navigate('/payment-success', { 
            state: { 
                course: course,
                enrollmentData: paymentData
            } 
        });
    };

    if (loading) {
        return (
            <Container className="py-5" style={{ marginTop: '76px' }}>
                <div className="text-center py-5">
                    <div className="spinner-border text-primary" style={{ width: '3rem', height: '3rem' }} role="status">
                        <span className="visually-hidden">Loading...</span>
                    </div>
                    <p className="mt-3 text-muted">Loading course details...</p>
                </div>
            </Container>
        );
    }

    if (error || !course) {
        return (
            <Container className="py-5" style={{ marginTop: '76px' }}>
                <Alert variant="danger" className="text-center">
                    <i className="fas fa-exclamation-triangle fa-2x mb-3"></i>
                    <h4>{error || 'Course not found'}</h4>
                    <p>The course you're looking for doesn't exist.</p>
                    <div className="mt-3">
                        <Button as={Link} to="/courses" variant="primary" className="me-2">
                            Browse All Courses
                        </Button>
                        <Button as={Link} to="/" variant="outline-primary">
                            Go Home
                        </Button>
                    </div>
                </Alert>
            </Container>
        );
    }

    return (
        <Container className="py-5" style={{ marginTop: '76px' }}>
            {/* Breadcrumb */}
            <nav aria-label="breadcrumb" className="mb-4">
                <ol className="breadcrumb">
                    <li className="breadcrumb-item">
                        <Link to="/" className="text-decoration-none">
                            <i className="fas fa-home me-1"></i>Home
                        </Link>
                    </li>
                    <li className="breadcrumb-item">
                        <Link to="/courses" className="text-decoration-none">Courses</Link>
                    </li>
                    <li className="breadcrumb-item active" aria-current="page">{course.title}</li>
                </ol>
            </nav>

            <Row>
                {/* Left Column - Course Content */}
                <Col lg={8}>
                    {/* Course Header */}
                    <div className="mb-4">
                        <Badge bg="primary" className="mb-2">{course.category}</Badge>
                        <Badge bg="outline-secondary" className="ms-2" text="dark">{course.difficulty}</Badge>
                        
                        <h1 className="display-5 fw-bold gradient-text mb-3">{course.title}</h1>
                        <p className="lead text-muted">{course.description}</p>
                        
                        <div className="d-flex flex-wrap align-items-center gap-3 mb-3">
                            <div className="d-flex align-items-center">
                                <i className="fas fa-star text-warning me-1"></i>
                                <span className="fw-semibold">{course.rating}</span>
                                <span className="text-muted ms-1">({Math.floor(course.students / 100)} reviews)</span>
                            </div>
                            <div className="d-flex align-items-center">
                                <i className="fas fa-users text-muted me-1"></i>
                                <span>{course.students.toLocaleString()}+ students</span>
                            </div>
                            <div className="d-flex align-items-center">
                                <i className="fas fa-clock text-muted me-1"></i>
                                <span>{course.duration}</span>
                            </div>
                            <div className="d-flex align-items-center">
                                <i className="fas fa-calendar text-muted me-1"></i>
                                <span>Last updated: {new Date(course.last_updated).toLocaleDateString()}</span>
                            </div>
                        </div>
                    </div>

                    {/* Course Image */}
                    <div className="mb-4">
                        <img 
                            src={course.image} 
                            alt={course.title}
                            className="img-fluid rounded-3 w-100 shadow-sm"
                            style={{ maxHeight: '400px', objectFit: 'cover' }}
                            onError={(e) => {
                                e.target.src = 'https://via.placeholder.com/800x400?text=Course+Image';
                            }}
                        />
                    </div>

                    {/* What You'll Learn */}
                    <Card className="mb-4 border-0 shadow-sm">
                        <Card.Header className="bg-primary text-white">
                            <h5 className="mb-0">
                                <i className="fas fa-bullseye me-2"></i>
                                What You'll Learn
                            </h5>
                        </Card.Header>
                        <Card.Body>
                            <Row>
                                <Col md={6}>
                                    <ListGroup variant="flush">
                                        <ListGroup.Item className="border-0 px-0">
                                            <i className="fas fa-check text-success me-2"></i>
                                            Master key concepts and techniques
                                        </ListGroup.Item>
                                        <ListGroup.Item className="border-0 px-0">
                                            <i className="fas fa-check text-success me-2"></i>
                                            Build real-world projects
                                        </ListGroup.Item>
                                        <ListGroup.Item className="border-0 px-0">
                                            <i className="fas fa-check text-success me-2"></i>
                                            Get hands-on experience
                                        </ListGroup.Item>
                                    </ListGroup>
                                </Col>
                                <Col md={6}>
                                    <ListGroup variant="flush">
                                        <ListGroup.Item className="border-0 px-0">
                                            <i className="fas fa-check text-success me-2"></i>
                                            Learn from industry experts
                                        </ListGroup.Item>
                                        <ListGroup.Item className="border-0 px-0">
                                            <i className="fas fa-check text-success me-2"></i>
                                            Get certificate of completion
                                        </ListGroup.Item>
                                        <ListGroup.Item className="border-0 px-0">
                                            <i className="fas fa-check text-success me-2"></i>
                                            Lifetime access to course materials
                                        </ListGroup.Item>
                                    </ListGroup>
                                </Col>
                            </Row>
                        </Card.Body>
                    </Card>

                    {/* Course Curriculum */}
                    <Card className="mb-4 border-0 shadow-sm">
                        <Card.Header className="bg-light">
                            <h5 className="mb-0">
                                <i className="fas fa-list-ol me-2"></i>
                                Course Curriculum
                            </h5>
                        </Card.Header>
                        <Card.Body>
                            <div className="accordion" id="curriculumAccordion">
                                {[1, 2, 3, 4].map((week) => (
                                    <div className="accordion-item" key={week}>
                                        <h2 className="accordion-header">
                                            <button 
                                                className="accordion-button collapsed" 
                                                type="button" 
                                                data-bs-toggle="collapse" 
                                                data-bs-target={`#week${week}`}
                                            >
                                                Week {week}: Introduction to Key Concepts
                                            </button>
                                        </h2>
                                        <div id={`week${week}`} className="accordion-collapse collapse" data-bs-parent="#curriculumAccordion">
                                            <div className="accordion-body">
                                                <ListGroup variant="flush">
                                                    <ListGroup.Item className="d-flex justify-content-between align-items-center border-0">
                                                        <span>
                                                            <i className="fas fa-play-circle text-primary me-2"></i>
                                                            Video Lecture: Introduction
                                                        </span>
                                                        <small className="text-muted">30 min</small>
                                                    </ListGroup.Item>
                                                    <ListGroup.Item className="d-flex justify-content-between align-items-center border-0">
                                                        <span>
                                                            <i className="fas fa-file-alt text-info me-2"></i>
                                                            Reading Materials
                                                        </span>
                                                        <small className="text-muted">45 min</small>
                                                    </ListGroup.Item>
                                                    <ListGroup.Item className="d-flex justify-content-between align-items-center border-0">
                                                        <span>
                                                            <i className="fas fa-tasks text-success me-2"></i>
                                                            Practice Exercise
                                                        </span>
                                                        <small className="text-muted">1 hour</small>
                                                    </ListGroup.Item>
                                                </ListGroup>
                                            </div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </Card.Body>
                    </Card>

                    {/* Instructor */}
                    <Card className="border-0 shadow-sm">
                        <Card.Header className="bg-light">
                            <h5 className="mb-0">
                                <i className="fas fa-user-tie me-2"></i>
                                Instructor
                            </h5>
                        </Card.Header>
                        <Card.Body>
                            <div className="d-flex align-items-start">
                                <div className="flex-shrink-0">
                                    <div 
                                        className="rounded-circle bg-primary d-flex align-items-center justify-content-center text-white fw-bold"
                                        style={{ width: '80px', height: '80px', fontSize: '2rem' }}
                                    >
                                        {course.instructor.split(' ').map(n => n[0]).join('')}
                                    </div>
                                </div>
                                <div className="flex-grow-1 ms-3">
                                    <h5 className="fw-bold">{course.instructor}</h5>
                                    <p className="text-muted mb-2">Senior Instructor & Industry Expert</p>
                                    <div className="d-flex flex-wrap gap-2 mb-2">
                                        <Badge bg="light" text="dark">
                                            <i className="fas fa-star text-warning me-1"></i>4.8 Rating
                                        </Badge>
                                        <Badge bg="light" text="dark">
                                            <i className="fas fa-users text-primary me-1"></i>10K+ Students
                                        </Badge>
                                        <Badge bg="light" text="dark">
                                            <i className="fas fa-play-circle text-success me-1"></i>15 Courses
                                        </Badge>
                                    </div>
                                    <p className="mb-0">
                                        {course.instructor} is an experienced professional with years of industry experience. 
                                        Passionate about teaching and helping students achieve their goals.
                                    </p>
                                </div>
                            </div>
                        </Card.Body>
                    </Card>
                </Col>

                {/* Right Column - Enrollment Card */}
                <Col lg={4}>
                    <Card className="sticky-top" style={{ top: '100px' }}>
                        <Card.Img 
                            variant="top" 
                            src={course.image} 
                            alt={course.title}
                            style={{ height: '200px', objectFit: 'cover' }}
                            onError={(e) => {
                                e.target.src = 'https://via.placeholder.com/400x200?text=Course+Image';
                            }}
                        />
                        <Card.Body className="text-center">
                            <div className="mb-3">
                                <h3 className="text-primary fw-bold">${course.price}</h3>
                                <p className="text-muted mb-0">One-time payment</p>
                            </div>
                            
                            <Button 
                                variant="primary" 
                                size="lg" 
                                className="w-100 mb-3 fw-semibold"
                                onClick={handleEnrollClick}
                            >
                                <i className="fas fa-shopping-cart me-2"></i>
                                Enroll Now
                            </Button>
                            
                            <Button 
                                variant="outline-secondary" 
                                size="sm" 
                                className="w-100 mb-3"
                            >
                                <i className="far fa-heart me-2"></i>
                                Add to Wishlist
                            </Button>

                            <div className="small text-muted">
                                <p className="mb-1">
                                    <i className="fas fa-shield-alt text-success me-2"></i>
                                    30-Day Money-Back Guarantee
                                </p>
                                <p className="mb-1">
                                    <i className="fas fa-infinity text-info me-2"></i>
                                    Full Lifetime Access
                                </p>
                                <p className="mb-1">
                                    <i className="fas fa-tablet-alt text-warning me-2"></i>
                                    Access on Mobile and TV
                                </p>
                                <p className="mb-0">
                                    <i className="fas fa-trophy text-primary me-2"></i>
                                    Certificate of Completion
                                </p>
                            </div>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>

            {/* Payment Modal */}
            <PaymentModal
                show={showPaymentModal}
                onHide={() => setShowPaymentModal(false)}
                course={course}
                onPaymentSuccess={handlePaymentSuccess}
            />
        </Container>
    );
};

export default CourseDetail;