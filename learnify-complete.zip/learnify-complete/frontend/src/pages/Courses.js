import React, { useState, useEffect } from 'react';
import { Container, Row, Col, Form, Button, InputGroup } from 'react-bootstrap';
import { useLocation } from 'react-router-dom';
import CourseCard from '../components/Courses/CourseCard';
import axios from 'axios';

const Courses = () => {
    const [courses, setCourses] = useState([]);
    const [filteredCourses, setFilteredCourses] = useState([]);
    const [categories, setCategories] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedCategory, setSelectedCategory] = useState('all');
    const [loading, setLoading] = useState(true);
    
    const location = useLocation();

    useEffect(() => {
        fetchCourses();
        fetchCategories();
    }, []);

    useEffect(() => {
        // Agar URL se category milti hai toh set karen
        if (location.state?.selectedCategory) {
            setSelectedCategory(location.state.selectedCategory);
        }
    }, [location.state]);

    useEffect(() => {
        filterCourses();
    }, [courses, searchTerm, selectedCategory]);

    const fetchCourses = async () => {
        try {
            const response = await axios.get('http://localhost:5000/api/courses');
            setCourses(response.data);
            setLoading(false);
        } catch (error) {
            console.error('Error fetching courses:', error);
            setLoading(false);
        }
    };

    const fetchCategories = async () => {
        try {
            const response = await axios.get('http://localhost:5000/api/categories');
            setCategories(response.data);
        } catch (error) {
            console.error('Error fetching categories:', error);
        }
    };

    const filterCourses = () => {
        let filtered = courses;

        // Filter by search term
        if (searchTerm) {
            filtered = filtered.filter(course =>
                course.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                course.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                course.instructor.toLowerCase().includes(searchTerm.toLowerCase())
            );
        }

        // Filter by category
        if (selectedCategory !== 'all') {
            filtered = filtered.filter(course => course.category === selectedCategory);
        }

        setFilteredCourses(filtered);
    };

    const clearFilters = () => {
        setSearchTerm('');
        setSelectedCategory('all');
    };

    if (loading) {
        return (
            <Container className="py-5" style={{ marginTop: '76px' }}>
                <div className="text-center py-5">
                    <div className="spinner-border text-primary" role="status">
                        <span className="visually-hidden">Loading...</span>
                    </div>
                    <p className="mt-3 text-muted">Loading courses...</p>
                </div>
            </Container>
        );
    }

    return (
        <Container className="py-5" style={{ marginTop: '76px' }}>
            {/* Header */}
            <Row className="mb-5">
                <Col>
                    <h1 className="display-4 fw-bold gradient-text text-center mb-3">
                        Explore Courses
                    </h1>
                    <p className="lead text-center text-muted">
                        Discover {courses.length}+ courses to advance your career
                    </p>
                </Col>
            </Row>

            {/* Search and Filters */}
            <Row className="mb-4">
                <Col lg={6}>
                    <InputGroup>
                        <InputGroup.Text>
                            <i className="fas fa-search"></i>
                        </InputGroup.Text>
                        <Form.Control
                            type="text"
                            placeholder="Search courses by title, description, or instructor..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                        />
                    </InputGroup>
                </Col>
                <Col lg={4}>
                    <Form.Select
                        value={selectedCategory}
                        onChange={(e) => setSelectedCategory(e.target.value)}
                    >
                        <option value="all">All Categories</option>
                        {categories.map(category => (
                            <option key={category} value={category}>{category}</option>
                        ))}
                    </Form.Select>
                </Col>
                <Col lg={2}>
                    <Button variant="outline-secondary" onClick={clearFilters} className="w-100">
                        <i className="fas fa-times me-2"></i>
                        Clear
                    </Button>
                </Col>
            </Row>

            {/* Results Count */}
            <Row className="mb-4">
                <Col>
                    <p className="text-muted">
                        Showing {filteredCourses.length} of {courses.length} courses
                        {searchTerm && ` for "${searchTerm}"`}
                        {selectedCategory !== 'all' && ` in ${selectedCategory}`}
                    </p>
                </Col>
            </Row>

            {/* Courses Grid */}
            <Row>
                {filteredCourses.length > 0 ? (
                    filteredCourses.map(course => (
                        <Col key={course.id} xl={3} lg={4} md={6} className="mb-4">
                            <CourseCard course={course} />
                        </Col>
                    ))
                ) : (
                    <Col className="text-center py-5">
                        <i className="fas fa-search fa-3x text-muted mb-3"></i>
                        <h4 className="text-muted">No courses found</h4>
                        <p className="text-muted">Try adjusting your search or filters</p>
                        <Button variant="primary" onClick={clearFilters}>
                            Clear Filters
                        </Button>
                    </Col>
                )}
            </Row>
        </Container>
    );
};

export default Courses;