import React, { useState } from 'react';
import { Modal, Button, Alert, Spinner, Card, Form } from 'react-bootstrap';
import axios from 'axios';
import { useAuth } from '../../context/AuthContext';

const PaymentModal = ({ show, onHide, course, onPaymentSuccess }) => {
     const { user } = useAuth();
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [paymentSuccess, setPaymentSuccess] = useState(false);
    const [cardDetails, setCardDetails] = useState({
        number: '4242424242424242',
        expiry: '12/25',
        cvc: '123',
        name: 'John Doe'
    });

    const handlePayment = async () => {
        try {
            setLoading(true);
            setError(null);

            console.log('💳 Starting payment process for course:', course.title);
            

            // Create demo payment intent
            const paymentResponse = await axios.post('http://localhost:5000/api/create-payment-intent', {
                courseId: course.id,
                amount: course.price,
                 userId: user?.id
            });

            console.log('✅ Payment intent created:', paymentResponse.data);

            // Simulate payment processing
              setTimeout(async () => {
               try {
                    // Confirm payment success with user ID
                    const successResponse = await axios.post('http://localhost:5000/api/payment-success', {
                        courseId: course.id,
                        userId: user?.id, // Send actual user ID
                        paymentIntentId: paymentResponse.data.paymentIntentId
                    });

                    if (successResponse.data.success) {
                        console.log('🎉 Payment successful for user:', user?.id);
                        setPaymentSuccess(true);
                        setTimeout(() => {
                            onPaymentSuccess(successResponse.data);
                            onHide();
                        }, 2000);
                    }
                } catch (error) {
                    console.error('❌ Payment confirmation error:', error);
                    setError('Payment failed. Please try again.');
                    setLoading(false);
                }
            }, 3000);
} catch (error) {
            console.error('❌ Payment error:', error);
            setError('Payment failed. Please try again.');
            setLoading(false);
        }
    };

    const handleClose = () => {
        setPaymentSuccess(false);
        setError(null);
        setLoading(false);
        onHide();
    };

    return (
        <Modal show={show} onHide={handleClose} size="lg" centered>
            <Modal.Header closeButton>
                <Modal.Title>
                    <i className="fas fa-credit-card me-2 text-primary"></i>
                    Complete Your Purchase
                </Modal.Title>
            </Modal.Header>
            
            <Modal.Body>
                {paymentSuccess ? (
                    <div className="text-center py-4">
                        <div className="text-success mb-3">
                            <i className="fas fa-check-circle fa-4x"></i>
                        </div>
                        <h4 className="text-success">Payment Successful!</h4>
                        <p className="text-muted">
                            You have successfully enrolled in <strong>{course.title}</strong>
                        </p>
                        <p>Redirecting to your courses...</p>
                    </div>
                ) : (
                    <>
                        {error && (
                            <Alert variant="danger" className="mb-3">
                                <i className="fas fa-exclamation-triangle me-2"></i>
                                {error}
                            </Alert>
                        )}

                        <div className="mb-4">
                            <Card className="border-0 bg-primary text-white">
                                <Card.Body className="text-center">
                                    <h4 className="mb-2">{course.title}</h4>
                                    <h2 className="mb-0">${course.price}</h2>
                                    <small>One-time payment</small>
                                </Card.Body>
                            </Card>
                        </div>

                        {/* Demo Payment Info */}
                        <Card className="bg-light border-0 mb-4">
                            <Card.Body>
                                <h6 className="mb-3 text-primary">
                                    <i className="fas fa-info-circle me-2"></i>
                                    Demo Payment Information
                                </h6>
                                <div className="row small">
                                    <div className="col-md-6">
                                        <div className="mb-2">
                                            <strong>Card Number:</strong>
                                            <div className="text-muted">4242 4242 4242 4242</div>
                                        </div>
                                        <div className="mb-2">
                                            <strong>Expiry Date:</strong>
                                            <div className="text-muted">12/25</div>
                                        </div>
                                    </div>
                                    <div className="col-md-6">
                                        <div className="mb-2">
                                            <strong>CVC:</strong>
                                            <div className="text-muted">123</div>
                                        </div>
                                        <div className="mb-2">
                                            <strong>Name:</strong>
                                            <div className="text-muted">John Doe</div>
                                        </div>
                                    </div>
                                </div>
                            </Card.Body>
                        </Card>

                        {/* Payment Form */}
                        <Card className="border-0 shadow-sm mb-4">
                            <Card.Body>
                                <h6 className="mb-3">Payment Details</h6>
                                <Form>
                                    <Form.Group className="mb-3">
                                        <Form.Label>Card Number</Form.Label>
                                        <Form.Control 
                                            type="text" 
                                            value={cardDetails.number}
                                            readOnly
                                            className="bg-light"
                                            placeholder="4242 4242 4242 4242"
                                        />
                                    </Form.Group>
                                    
                                    <div className="row">
                                        <div className="col-md-6">
                                            <Form.Group className="mb-3">
                                                <Form.Label>Expiry Date</Form.Label>
                                                <Form.Control 
                                                    type="text" 
                                                    value={cardDetails.expiry}
                                                    readOnly
                                                    className="bg-light"
                                                    placeholder="MM/YY"
                                                />
                                            </Form.Group>
                                        </div>
                                        <div className="col-md-6">
                                            <Form.Group className="mb-3">
                                                <Form.Label>CVC</Form.Label>
                                                <Form.Control 
                                                    type="text" 
                                                    value={cardDetails.cvc}
                                                    readOnly
                                                    className="bg-light"
                                                    placeholder="123"
                                                />
                                            </Form.Group>
                                        </div>
                                    </div>
                                    
                                    <Form.Group className="mb-3">
                                        <Form.Label>Cardholder Name</Form.Label>
                                        <Form.Control 
                                            type="text" 
                                            value={cardDetails.name}
                                            readOnly
                                            className="bg-light"
                                            placeholder="John Doe"
                                        />
                                    </Form.Group>
                                </Form>
                            </Card.Body>
                        </Card>

                        {/* Features */}
                        <div className="bg-light rounded p-3 mb-4">
                            <h6 className="mb-3">What you get:</h6>
                            <div className="row small text-muted">
                                <div className="col-md-6">
                                    <p className="mb-2">
                                        <i className="fas fa-check text-success me-2"></i>
                                        Lifetime access
                                    </p>
                                    <p className="mb-2">
                                        <i className="fas fa-check text-success me-2"></i>
                                        Certificate of completion
                                    </p>
                                </div>
                                <div className="col-md-6">
                                    <p className="mb-2">
                                        <i className="fas fa-check text-success me-2"></i>
                                        Downloadable resources
                                    </p>
                                    <p className="mb-0">
                                        <i className="fas fa-check text-success me-2"></i>
                                        30-day money-back guarantee
                                    </p>
                                </div>
                            </div>
                        </div>

                        <div className="mt-4">
                            <Button
                                variant="primary"
                                onClick={handlePayment}
                                disabled={loading}
                                className="w-100 py-3"
                                size="lg"
                            >
                                {loading ? (
                                    <>
                                        <Spinner animation="border" size="sm" className="me-2" />
                                        Processing Payment...
                                    </>
                                ) : (
                                    <>
                                        <i className="fas fa-lock me-2"></i>
                                        Pay ${course.price} Now
                                    </>
                                )}
                            </Button>
                            
                            <Button
                                variant="outline-secondary"
                                onClick={handleClose}
                                className="w-100 mt-2"
                                disabled={loading}
                            >
                                <i className="fas fa-times me-2"></i>
                                Cancel
                            </Button>

                            <div className="text-center mt-3">
                                <small className="text-muted">
                                    <i className="fas fa-shield-alt me-1"></i>
                                    Secure payment. Your information is safe.
                                </small>
                            </div>
                        </div>
                    </>
                )}
            </Modal.Body>
        </Modal>
    );
};

export default PaymentModal;