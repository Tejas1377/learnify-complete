import React from 'react';
import { Container, Row, Col, Button, Badge } from 'react-bootstrap';
import { Link } from 'react-router-dom';

const HeroSection = () => {
    return (
        <section className="hero-gradient text-white py-5" style={{ marginTop: '76px' }}>
            <Container>
                <Row className="align-items-center min-vh-50 py-5">
                    <Col lg={6}>
                        <Badge bg="warning" text="dark" className="mb-3 p-2">
                            <i className="fas fa-star me-1"></i>
                            Trusted by 10,000+ Students
                        </Badge>
                        <h1 className="display-4 fw-bold mb-4">
                            Learn Without <span className="text-warning">Limits</span>
                        </h1>
                        <p className="lead mb-4">
                            Access 24+ professional courses, learn from industry experts, and advance your career. 
                            Join our community of passionate learners today.
                        </p>
                        <div className="d-flex flex-wrap gap-3 mb-4">
                            <Button 
                                as={Link} 
                                to="/courses" 
                                variant="warning" 
                                size="lg" 
                                className="fw-semibold px-4"
                            >
                                <i className="fas fa-rocket me-2"></i>
                                Explore Courses
                            </Button>
                            <Button 
                                as={Link} 
                                to="/register" 
                                variant="outline-light" 
                                size="lg"
                                className="px-4"
                            >
                                <i className="fas fa-user-plus me-2"></i>
                                Join Free
                            </Button>
                        </div>
                        <div className="d-flex flex-wrap gap-4 text-light">
                            <div>
                                <i className="fas fa-check-circle text-success me-2"></i>
                                24+ Courses
                            </div>
                            <div>
                                <i className="fas fa-check-circle text-success me-2"></i>
                                10+ Categories
                            </div>
                            <div>
                                <i className="fas fa-check-circle text-success me-2"></i>
                                Lifetime Access
                            </div>
                        </div>
                    </Col>
                    <Col lg={6}>
                        <div className="text-center position-relative">
                            <img 
                                src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=600" 
                                alt="Learning" 
                                className="img-fluid rounded-3 shadow-lg"
                            />
                            {/* Floating elements */}
                            <div className="position-absolute top-0 start-0 bg-white rounded-circle p-3 shadow m-3">
                                <i className="fas fa-graduation-cap fa-2x text-primary"></i>
                            </div>
                            <div className="position-absolute top-0 end-0 bg-white rounded-circle p-3 shadow m-3">
                                <i className="fas fa-trophy fa-2x text-warning"></i>
                            </div>
                            <div className="position-absolute bottom-0 start-0 bg-white rounded-circle p-3 shadow m-3">
                                <i className="fas fa-certificate fa-2x text-success"></i>
                            </div>
                        </div>
                    </Col>
                </Row>
            </Container>
        </section>
    );
};

export default HeroSection;