import React from 'react';
import { Container, Row, Col, Card } from 'react-bootstrap';

const FeaturesSection = () => {
    const features = [
        {
            icon: 'fas fa-laptop-code',
            title: 'Learn Anywhere',
            description: 'Access courses on any device, anytime with our mobile-friendly platform.'
        },
        {
            icon: 'fas fa-chart-line',
            title: 'Career Growth',
            description: 'Gain skills that companies are looking for and advance your career.'
        },
        {
            icon: 'fas fa-users',
            title: 'Expert Instructors',
            description: 'Learn from industry professionals with real-world experience.'
        },
        {
            icon: 'fas fa-certificate',
            title: 'Get Certified',
            description: 'Earn certificates to showcase your skills to employers.'
        }
    ];

    return (
        <section className="py-5 bg-light">
            <Container>
                <Row className="text-center mb-5">
                    <Col>
                        <h2 className="display-5 fw-bold gradient-text mb-3">Why Choose Learnify?</h2>
                        <p className="lead text-muted">Discover what makes our platform different</p>
                    </Col>
                </Row>
                <Row>
                    {features.map((feature, index) => (
                        <Col lg={3} md={6} key={index} className="mb-4">
                            <Card className="card-hover h-100 text-center border-0">
                                <Card.Body className="p-4">
                                    <div className="feature-icon mb-3">
                                        <i className={`${feature.icon} fa-3x text-primary`}></i>
                                    </div>
                                    <Card.Title className="h5 fw-bold">{feature.title}</Card.Title>
                                    <Card.Text className="text-muted">
                                        {feature.description}
                                    </Card.Text>
                                </Card.Body>
                            </Card>
                        </Col>
                    ))}
                </Row>
            </Container>
        </section>
    );
};

export default FeaturesSection;