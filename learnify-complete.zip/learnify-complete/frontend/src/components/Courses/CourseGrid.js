import React, { useState, useEffect } from 'react';
import { Row, Col, Alert } from 'react-bootstrap';
import CourseCard from './CourseCard';
import axios from 'axios';

const CourseGrid = ({ limit = 12, category = null }) => {
    const [courses, setCourses] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        fetchCourses();
    }, [limit, category]);

    const fetchCourses = async () => {
        try {
            console.log('🔄 Fetching courses...', { category, limit });
            setLoading(true);
            setError(null);

            let apiUrl = 'http://localhost:5000/api/courses';
            
            // Use popular endpoint if no category specified
            if (!category) {
                apiUrl = 'http://localhost:5000/api/courses/popular';
            }

            console.log('📡 API URL:', apiUrl);
            const response = await axios.get(apiUrl);
            console.log('✅ API Response received, courses count:', response.data.length);

            let filteredCourses = response.data;
            
            // Filter by category if specified
            if (category && category !== 'all') {
                filteredCourses = filteredCourses.filter(course => 
                    course.category === category
                );
                console.log('📂 Filtered by category:', category, 'Count:', filteredCourses.length);
            }
            
            // Apply limit
            const finalCourses = limit ? filteredCourses.slice(0, limit) : filteredCourses;
            
            console.log('🎯 Final courses to display:', finalCourses.length);
            setCourses(finalCourses);

        } catch (error) {
            console.error('❌ Error fetching courses:', error);
            setError('Failed to load courses. Please check if the server is running.');
        } finally {
            setLoading(false);
        }
    };

    // Loading state
    if (loading) {
        return (
            <div className="text-center py-5">
                <div className="spinner-border text-primary" style={{ width: '3rem', height: '3rem' }} role="status">
                    <span className="visually-hidden">Loading...</span>
                </div>
                <p className="mt-3 text-muted">Loading courses...</p>
            </div>
        );
    }

    // Error state
    if (error) {
        return (
            <Alert variant="warning" className="text-center">
                <i className="fas fa-exclamation-triangle me-2"></i>
                {error}
                <div className="mt-2">
                    <button 
                        className="btn btn-primary btn-sm"
                        onClick={fetchCourses}
                    >
                        Try Again
                    </button>
                </div>
            </Alert>
        );
    }

    // No courses found
    if (courses.length === 0) {
        return (
            <div className="text-center py-5">
                <i className="fas fa-book-open fa-3x text-muted mb-3"></i>
                <h4 className="text-muted">No courses found</h4>
                <p className="text-muted">
                    {category ? `No courses in "${category}" category` : 'No popular courses available'}
                </p>
            </div>
        );
    }

    // Display courses
    return (
        <Row>
            {courses.map(course => (
                <Col key={course.id} xl={3} lg={4} md={6} className="mb-4">
                    <CourseCard course={course} />
                </Col>
            ))}
        </Row>
    );
};

export default CourseGrid;