import React from 'react';
import { Card, Button, Badge } from 'react-bootstrap';
import { Link } from 'react-router-dom';

const CourseCard = ({ course }) => {
    if (!course) {
        return <div>No course data</div>;
    }

    return (
        <Card className="h-100 course-card shadow-sm border-0">
            <Card.Img 
                variant="top" 
                src={course.image} 
                alt={course.title}
                style={{ height: '200px', objectFit: 'cover' }}
                onError={(e) => {
                    e.target.src = 'https://via.placeholder.com/400x200?text=Course+Image';
                }}
            />
            <Card.Body className="d-flex flex-column">
                <div className="mb-2">
                    <Badge bg="primary" className="mb-2">
                        {course.category}
                    </Badge>
                    <Badge bg="outline-secondary" className="ms-1" text="dark">
                        {course.difficulty}
                    </Badge>
                </div>
                
                <Card.Title className="h5" style={{ minHeight: '48px' }}>
                    {course.title}
                </Card.Title>
                
                <Card.Text className="text-muted flex-grow-1" style={{ minHeight: '60px' }}>
                    {course.description && course.description.length > 80 
                        ? `${course.description.substring(0, 80)}...` 
                        : course.description
                    }
                </Card.Text>
                
                <div className="mt-auto">
                    <div className="d-flex justify-content-between align-items-center mb-2">
                        <small className="text-warning fw-bold">
                            <i className="fas fa-star"></i> {course.rating}
                        </small>
                        <small className="text-muted">
                            <i className="fas fa-users"></i> {course.students}+
                        </small>
                        <small className="text-muted">
                            <i className="fas fa-clock"></i> {course.duration}
                        </small>
                    </div>
                    
                    <div className="d-flex justify-content-between align-items-center mt-2">
                        <strong className="text-primary h5 mb-0">${course.price}</strong>
                        <div>
                            <small className="text-muted d-block">{course.instructor}</small>
                        </div>
                    </div>
                    
                    {/* Updated Button to Link to CourseDetail */}
                    <Button 
                        as={Link} 
                        to={`/course/${course.id}`}  // Changed this line
                        variant="primary" 
                        size="sm"
                        className="w-100 mt-2"
                    >
                        <i className="fas fa-eye me-1"></i>
                        View Course
                    </Button>
                </div>
            </Card.Body>
        </Card>
    );
};

export default CourseCard;