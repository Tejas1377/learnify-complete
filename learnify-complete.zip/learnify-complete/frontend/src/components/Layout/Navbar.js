import React from 'react';
import { Navbar, Nav, Container, Dropdown, Badge, Spinner } from 'react-bootstrap';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

const CustomNavbar = () => {
    const { user, logout, loading } = useAuth();
    const location = useLocation();
    const navigate = useNavigate();

    const handleLogout = () => {
        logout();
        navigate('/');
    };

    const isActive = (path) => {
        return location.pathname === path;
    };

    // Show loading spinner while checking authentication
    if (loading) {
        return (
            <Navbar expand="lg" className="navbar-blur fixed-top shadow-sm" style={{ backgroundColor: 'rgba(255, 255, 255, 0.95)' }}>
                <Container>
                    <Navbar.Brand as={Link} to="/" className="fw-bold fs-3 gradient-text">
                        <i className="fas fa-graduation-cap me-2"></i>
                        Learnify
                    </Navbar.Brand>
                    <div className="ms-auto">
                        <Spinner animation="border" size="sm" className="me-2" />
                        <small className="text-muted">Loading...</small>
                    </div>
                </Container>
            </Navbar>
        );
    }

    return (
        <Navbar expand="lg" className="navbar-blur fixed-top shadow-sm" style={{ backgroundColor: 'rgba(255, 255, 255, 0.95)' }}>
            <Container>
                {/* Brand Logo */}
                <Navbar.Brand as={Link} to="/" className="fw-bold fs-3 gradient-text">
                    <i className="fas fa-graduation-cap me-2"></i>
                    Learnify
                </Navbar.Brand>
                
                {/* Mobile Toggle */}
                <Navbar.Toggle aria-controls="basic-navbar-nav">
                    <i className="fas fa-bars"></i>
                </Navbar.Toggle>
                
                <Navbar.Collapse id="basic-navbar-nav">
                    {/* Navigation Links */}
                    <Nav className="mx-auto">
                        <Nav.Link 
                            as={Link} 
                            to="/" 
                            className={`fw-semibold mx-2 ${isActive('/') ? 'text-primary' : 'text-dark'}`}
                        >
                            <i className="fas fa-home me-1"></i> Home
                        </Nav.Link>
                        <Nav.Link 
                            as={Link} 
                            to="/courses" 
                            className={`fw-semibold mx-2 ${isActive('/courses') ? 'text-primary' : 'text-dark'}`}
                        >
                            <i className="fas fa-book me-1"></i> Courses
                        </Nav.Link>
                        {user && (
                            <Nav.Link 
                                as={Link} 
                                to="/dashboard" 
                                className={`fw-semibold mx-2 ${isActive('/dashboard') ? 'text-primary' : 'text-dark'}`}
                            >
                                <i className="fas fa-tachometer-alt me-1"></i> Dashboard
                            </Nav.Link>
                        )}
                    </Nav>
                    
                    {/* Right Side - User Actions */}
                    <Nav>
                        {user ? (
                            // User is logged in - Show actual user data from AuthContext
                            <div className="d-flex align-items-center">
                                {/* Notifications */}
                                <Dropdown className="me-3">
                                    <Dropdown.Toggle variant="outline-secondary" size="sm" className="position-relative border-0">
                                        <i className="fas fa-bell"></i>
                                        <Badge 
                                            bg="danger" 
                                            className="position-absolute top-0 start-100 translate-middle p-1"
                                            style={{ fontSize: '0.6rem' }}
                                        >
                                            3
                                        </Badge>
                                    </Dropdown.Toggle>
                                    <Dropdown.Menu>
                                        <Dropdown.Header>Notifications</Dropdown.Header>
                                        <Dropdown.Item>
                                            <small>📚 New course available</small>
                                        </Dropdown.Item>
                                        <Dropdown.Item>
                                            <small>🎯 Assignment due tomorrow</small>
                                        </Dropdown.Item>
                                        <Dropdown.Item>
                                            <small>🏆 You earned a badge!</small>
                                        </Dropdown.Item>
                                        <Dropdown.Divider />
                                        <Dropdown.Item className="text-center text-primary">
                                            <small>View All</small>
                                        </Dropdown.Item>
                                    </Dropdown.Menu>
                                </Dropdown>

                                {/* User Dropdown - Shows ACTUAL user data from AuthContext */}
                                <Dropdown>
                                    <Dropdown.Toggle 
                                        variant="outline-primary" 
                                        id="dropdown-basic" 
                                        className="d-flex align-items-center"
                                    >
                                        <img 
                                            src={user.avatar} 
                                            alt={user.name}
                                            className="rounded-circle me-2"
                                            style={{ width: '32px', height: '32px', objectFit: 'cover' }}
                                            onError={(e) => {
                                                e.target.src = `https://ui-avatars.com/api/?name=${encodeURIComponent(user.name)}&background=6366f1&color=fff`;
                                            }}
                                        />
                                        <span className="d-none d-md-inline">{user.name}</span>
                                    </Dropdown.Toggle>
                                    <Dropdown.Menu align="end">
                                        <Dropdown.Header>
                                            <div className="text-center">
                                                <img 
                                                    src={user.avatar} 
                                                    alt={user.name}
                                                    className="rounded-circle mb-2"
                                                    style={{ width: '64px', height: '64px', objectFit: 'cover' }}
                                                    onError={(e) => {
                                                        e.target.src = `https://ui-avatars.com/api/?name=${encodeURIComponent(user.name)}&background=6366f1&color=fff`;
                                                    }}
                                                />
                                                <h6 className="mb-0">{user.name}</h6>
                                                <small className="text-muted">{user.email}</small>
                                            </div>
                                        </Dropdown.Header>
                                        <Dropdown.Divider />
                                        <Dropdown.Item as={Link} to="/dashboard" className="d-flex align-items-center">
                                            <i className="fas fa-tachometer-alt me-2 text-success"></i>
                                            Dashboard
                                        </Dropdown.Item>
                                        <Dropdown.Item as={Link} to="/courses" className="d-flex align-items-center">
                                            <i className="fas fa-book me-2 text-info"></i>
                                            My Courses
                                        </Dropdown.Item>
                                        <Dropdown.Divider />
                                        <Dropdown.Item className="d-flex align-items-center">
                                            <i className="fas fa-cog me-2 text-secondary"></i>
                                            Settings
                                        </Dropdown.Item>
                                        <Dropdown.Item className="d-flex align-items-center">
                                            <i className="fas fa-question-circle me-2 text-secondary"></i>
                                            Help & Support
                                        </Dropdown.Item>
                                        <Dropdown.Divider />
                                        <Dropdown.Item 
                                            onClick={handleLogout}
                                            className="d-flex align-items-center text-danger"
                                        >
                                            <i className="fas fa-sign-out-alt me-2"></i>
                                            Logout
                                        </Dropdown.Item>
                                    </Dropdown.Menu>
                                </Dropdown>
                            </div>
                        ) : (
                            // User is not logged in
                            <div className="d-flex align-items-center">
                                <Nav.Link 
                                    as={Link} 
                                    to="/login" 
                                    className={`fw-semibold mx-2 ${isActive('/login') ? 'text-primary' : 'text-dark'}`}
                                >
                                    <i className="fas fa-sign-in-alt me-1"></i> Login
                                </Nav.Link>
                                <Link to="/register" className="btn btn-primary btn-sm">
                                    <i className="fas fa-user-plus me-1"></i> Sign Up
                                </Link>
                            </div>
                        )}
                    </Nav>
                </Navbar.Collapse>
            </Container>
        </Navbar>
    );
};

export default CustomNavbar;