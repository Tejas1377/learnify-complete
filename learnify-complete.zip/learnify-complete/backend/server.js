const express = require('express');
const cors = require('cors');
const mysql = require('mysql2/promise');
require('dotenv').config();

const app = express();

// Enable CORS for all routes
app.use(cors({
    origin: 'http://localhost:3000',
    credentials: true
}));
app.use(express.json());

// Demo users database
let users = [
    {
        id: 1,
        name: "John Doe",
        email: "john@example.com",
        password: "password123",
        avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150"
    },
    {
        id: 2,
        name: "Sarah Johnson",
        email: "sarah@example.com", 
        password: "password123",
        avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150"
    }
];

// Demo enrollments - ab user-specific hoga
let enrollments = [
    // Demo data - John Doe (user 1) ne 4 courses enroll kiye hain, 2 complete kiye hain
    {
        id: 'enroll_1',
        userId: 1,
        courseId: 1,
        paymentIntentId: 'demo_pi_1',
        enrolledAt: "2024-01-15T10:30:00Z",
        status: 'active',
        progress: 45,
        completed: false
    },
    {
        id: 'enroll_2',
        userId: 1,
        courseId: 2,
        paymentIntentId: 'demo_pi_2',
        enrolledAt: "2024-01-10T14:20:00Z",
        status: 'active',
        progress: 100,
        completed: true
    },
    {
        id: 'enroll_3',
        userId: 1,
        courseId: 3,
        paymentIntentId: 'demo_pi_3',
        enrolledAt: "2024-01-08T09:15:00Z",
        status: 'active',
        progress: 100,
        completed: true
    },
    {
        id: 'enroll_4',
        userId: 1,
        courseId: 4,
        paymentIntentId: 'demo_pi_4',
        enrolledAt: "2024-01-12T16:45:00Z",
        status: 'active',
        progress: 30,
        completed: false
    }
];

// Test endpoint
app.get('/api/test', (req, res) => {
    res.json({ 
        message: 'Backend is working!',
        timestamp: new Date().toISOString(),
        usersCount: users.length
    });
});

// Register endpoint
app.post('/api/auth/register', (req, res) => {
    try {
        console.log('📨 Registration request received:', req.body);
        
        const { name, email, password } = req.body;
        
        // Check if all fields are provided
        if (!name || !email || !password) {
            console.log('❌ Missing fields');
            return res.status(400).json({ 
                success: false,
                error: 'All fields are required' 
            });
        }
        
        // Check if user already exists
        const existingUser = users.find(user => user.email === email);
        if (existingUser) {
            console.log('❌ User already exists:', email);
            return res.status(400).json({ 
                success: false,
                error: 'User already exists with this email' 
            });
        }
        
        // Create new user
        const newUser = {
            id: users.length + 1,
            name: name.trim(),
            email: email.toLowerCase().trim(),
            password: password,
            avatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=6366f1&color=fff&bold=true`
        };
        
        users.push(newUser);
        
        console.log('✅ New user registered:', newUser.name);
        
        res.json({
            success: true,
            message: 'Registration successful! Please login with your credentials.',
            user: {
                id: newUser.id,
                name: newUser.name,
                email: newUser.email,
                avatar: newUser.avatar
            }
        });
        
    } catch (error) {
        console.error('💥 Registration error:', error);
        res.status(500).json({
            success: false,
            error: 'Internal server error'
        });
    }
});

// Login endpoint
app.post('/api/auth/login', (req, res) => {
    try {
        const { email, password } = req.body;
        
        console.log('🔐 Login attempt:', email);
        
        // Find user
        const user = users.find(u => u.email === email && u.password === password);
        
        if (!user) {
            return res.status(401).json({ 
                success: false,
                error: 'Invalid email or password' 
            });
        }
        
        res.json({
            success: true,
            token: `demo-token-${Date.now()}`,
            user: {
                id: user.id,
                name: user.name,
                email: user.email,
                avatar: user.avatar
            }
        });
        
    } catch (error) {
        console.error('💥 Login error:', error);
        res.status(500).json({
            success: false,
            error: 'Internal server error'
        });
    }
});

// Sample courses data (24 courses - same as before)
const sampleCourses = [
    {
        id: 1,
        title: "Web Development Masterclass",
        description: "Learn full-stack web development from scratch with HTML, CSS, JavaScript, React, and Node.js",
        category: "Development",
        difficulty: "Beginner",
        duration: "40 hours",
        students: 1250,
        rating: 4.8,
        image: "https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=400",
        price: 49.99,
        instructor: "Sarah Johnson",
        last_updated: "2024-01-15"
    },
    {
        id: 2,
        title: "Data Science Fundamentals",
        description: "Master data analysis, visualization, and machine learning with Python and R",
        category: "Data Science",
        difficulty: "Intermediate",
        duration: "35 hours",
        students: 890,
        rating: 4.7,
        image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=400",
        price: 59.99,
        instructor: "Mike Chen",
        last_updated: "2024-01-10"
    },
    {
        id: 3,
        title: "Mobile App Development",
        description: "Build cross-platform mobile applications using React Native and Flutter",
        category: "Development",
        difficulty: "Intermediate",
        duration: "45 hours",
        students: 670,
        rating: 4.6,
        image: "https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?w=400",
        price: 54.99,
        instructor: "Alex Rodriguez",
        last_updated: "2024-01-08"
    },
    {
        id: 4,
        title: "Digital Marketing Pro",
        description: "Complete digital marketing strategy including SEO, SEM, and social media marketing",
        category: "Marketing",
        difficulty: "Beginner",
        duration: "30 hours",
        students: 2100,
        rating: 4.9,
        image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=400",
        price: 39.99,
        instructor: "Emily Davis",
        last_updated: "2024-01-12"
    },
    {
        id: 5,
        title: "UI/UX Design Principles",
        description: "Learn modern UI/UX design techniques, prototyping, and user research methods",
        category: "Design",
        difficulty: "Beginner",
        duration: "25 hours",
        students: 1500,
        rating: 4.8,
        image: "https://images.unsplash.com/photo-1561070791-2526d30994b5?w=400",
        price: 44.99,
        instructor: "David Kim",
        last_updated: "2024-01-05"
    },
    {
        id: 6,
        title: "Python for AI & ML",
        description: "Advanced Python programming for artificial intelligence and machine learning projects",
        category: "Programming",
        difficulty: "Advanced",
        duration: "50 hours",
        students: 520,
        rating: 4.7,
        image: "https://images.unsplash.com/photo-1526379879527-8559ecfcaec0?w=400",
        price: 69.99,
        instructor: "Dr. James Wilson",
        last_updated: "2024-01-18"
    },
    {
        id: 7,
        title: "Cloud Computing with AWS",
        description: "Master Amazon Web Services including EC2, S3, Lambda, and cloud architecture",
        category: "Cloud",
        difficulty: "Intermediate",
        duration: "38 hours",
        students: 980,
        rating: 4.7,
        image: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=400",
        price: 59.99,
        instructor: "Raj Patel",
        last_updated: "2024-01-20"
    },
    {
        id: 8,
        title: "JavaScript Frameworks",
        description: "Comprehensive guide to React, Vue, Angular, and modern JavaScript frameworks",
        category: "Development",
        difficulty: "Intermediate",
        duration: "42 hours",
        students: 1100,
        rating: 4.6,
        image: "https://images.unsplash.com/photo-1579468118864-1b9ea3c0db4a?w=400",
        price: 52.99,
        instructor: "Maria Garcia",
        last_updated: "2024-01-14"
    },
    {
        id: 9,
        title: "Cybersecurity Essentials",
        description: "Learn network security, ethical hacking, and cybersecurity best practices",
        category: "Security",
        difficulty: "Intermediate",
        duration: "36 hours",
        students: 720,
        rating: 4.8,
        image: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=400",
        price: 64.99,
        instructor: "Chris Thompson",
        last_updated: "2024-01-22"
    },
    {
        id: 10,
        title: "Business Analytics",
        description: "Data-driven decision making with Excel, SQL, and business intelligence tools",
        category: "Business",
        difficulty: "Beginner",
        duration: "28 hours",
        students: 1350,
        rating: 4.5,
        image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=400",
        price: 47.99,
        instructor: "Lisa Wang",
        last_updated: "2024-01-16"
    },
    {
        id: 11,
        title: "Full Stack Development",
        description: "End-to-end web development with MERN stack (MongoDB, Express, React, Node.js)",
        category: "Development",
        difficulty: "Advanced",
        duration: "55 hours",
        students: 890,
        rating: 4.8,
        image: "https://images.unsplash.com/photo-1627398242454-45a1465c2479?w=400",
        price: 74.99,
        instructor: "Kevin Martin",
        last_updated: "2024-01-25"
    },
    {
        id: 12,
        title: "Graphic Design Mastery",
        description: "Professional graphic design with Adobe Photoshop, Illustrator, and InDesign",
        category: "Design",
        difficulty: "Beginner",
        duration: "32 hours",
        students: 1650,
        rating: 4.7,
        image: "https://images.unsplash.com/photo-1561070791-2526d30994b5?w=400",
        price: 49.99,
        instructor: "Sophia Lee",
        last_updated: "2024-01-19"
    },
    {
        id: 13,
        title: "DevOps Engineering",
        description: "CI/CD pipelines, Docker, Kubernetes, and infrastructure as code",
        category: "DevOps",
        difficulty: "Advanced",
        duration: "48 hours",
        students: 610,
        rating: 4.9,
        image: "https://images.unsplash.com/photo-1504639725590-34d0984388bd?w=400",
        price: 79.99,
        instructor: "Daniel Brown",
        last_updated: "2024-01-23"
    },
    {
        id: 14,
        title: "iOS App Development",
        description: "Build native iOS applications with Swift and SwiftUI",
        category: "Development",
        difficulty: "Intermediate",
        duration: "40 hours",
        students: 780,
        rating: 4.6,
        image: "https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?w=400",
        price: 57.99,
        instructor: "Anna Taylor",
        last_updated: "2024-01-17"
    },
    {
        id: 15,
        title: "Content Writing & SEO",
        description: "Master content creation, copywriting, and search engine optimization",
        category: "Marketing",
        difficulty: "Beginner",
        duration: "24 hours",
        students: 1950,
        rating: 4.5,
        image: "https://images.unsplash.com/photo-1432888622747-4eb9a8efeb07?w=400",
        price: 34.99,
        instructor: "Michael Roberts",
        last_updated: "2024-01-13"
    },
    {
        id: 16,
        title: "Blockchain Development",
        description: "Smart contracts, Ethereum, Solidity, and decentralized applications",
        category: "Development",
        difficulty: "Advanced",
        duration: "52 hours",
        students: 430,
        rating: 4.8,
        image: "https://images.unsplash.com/photo-1639762681485-074b7f938ba0?w=400",
        price: 84.99,
        instructor: "Carlos Hernandez",
        last_updated: "2024-01-26"
    },
    {
        id: 17,
        title: "Project Management",
        description: "Agile, Scrum, and project management methodologies for tech projects",
        category: "Business",
        difficulty: "Intermediate",
        duration: "30 hours",
        students: 1120,
        rating: 4.6,
        image: "https://images.unsplash.com/photo-1552664730-d307ca884978?w=400",
        price: 44.99,
        instructor: "Jennifer Lopez",
        last_updated: "2024-01-21"
    },
    {
        id: 18,
        title: "Machine Learning with Python",
        description: "Practical machine learning algorithms and neural networks implementation",
        category: "Data Science",
        difficulty: "Intermediate",
        duration: "45 hours",
        students: 920,
        rating: 4.7,
        image: "https://images.unsplash.com/photo-1555255707-c07966088b7b?w=400",
        price: 62.99,
        instructor: "Dr. Robert Kim",
        last_updated: "2024-01-24"
    },
    {
        id: 19,
        title: "Video Editing Masterclass",
        description: "Professional video editing with Adobe Premiere Pro and After Effects",
        category: "Design",
        difficulty: "Beginner",
        duration: "35 hours",
        students: 1280,
        rating: 4.5,
        image: "https://images.unsplash.com/photo-1593508512255-86ab42a8e620?w=400",
        price: 49.99,
        instructor: "Ryan Cooper",
        last_updated: "2024-01-11"
    },
    {
        id: 20,
        title: "Database Management",
        description: "SQL, NoSQL, database design, and optimization techniques",
        category: "Development",
        difficulty: "Intermediate",
        duration: "38 hours",
        students: 850,
        rating: 4.6,
        image: "https://images.unsplash.com/photo-1544383835-bda2bc66a55d?w=400",
        price: 54.99,
        instructor: "Amanda White",
        last_updated: "2024-01-27"
    },
    {
        id: 21,
        title: "Social Media Marketing",
        description: "Grow your brand with Facebook, Instagram, Twitter, and LinkedIn strategies",
        category: "Marketing",
        difficulty: "Beginner",
        duration: "26 hours",
        students: 1750,
        rating: 4.4,
        image: "https://images.unsplash.com/photo-1432888622747-4eb9a8efeb07?w=400",
        price: 39.99,
        instructor: "Jessica Miller",
        last_updated: "2024-01-09"
    },
    {
        id: 22,
        title: "Game Development with Unity",
        description: "Create 2D and 3D games using Unity game engine and C#",
        category: "Development",
        difficulty: "Intermediate",
        duration: "50 hours",
        students: 590,
        rating: 4.7,
        image: "https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=400",
        price: 67.99,
        instructor: "Tom Anderson",
        last_updated: "2024-01-28"
    },
    {
        id: 23,
        title: "Network Administration",
        description: "Network setup, security, and administration for IT professionals",
        category: "IT",
        difficulty: "Intermediate",
        duration: "42 hours",
        students: 680,
        rating: 4.5,
        image: "https://images.unsplash.com/photo-1544197150-b99a580bb7a8?w=400",
        price: 59.99,
        instructor: "Brian Wilson",
        last_updated: "2024-01-29"
    },
    {
        id: 24,
        title: "Photography Fundamentals",
        description: "Master camera techniques, composition, and photo editing",
        category: "Design",
        difficulty: "Beginner",
        duration: "28 hours",
        students: 1420,
        rating: 4.6,
        image: "https://images.unsplash.com/photo-1554048612-b6a482bc67e5?w=400",
        price: 42.99,
        instructor: "Emma Davis",
        last_updated: "2024-01-30"
    }
];

// ==================== COURSE ENDPOINTS ====================

// Get all courses
app.get('/api/courses', (req, res) => {
    console.log('📚 Fetching all courses');
    res.json(sampleCourses);
});

// Popular courses endpoint
app.get('/api/courses/popular', (req, res) => {
    console.log('🔥 Fetching popular courses');
    const popularCourses = [...sampleCourses]
        .sort((a, b) => {
            if (b.rating !== a.rating) {
                return b.rating - a.rating;
            }
            return b.students - a.students;
        })
        .slice(0, 12);
    
    res.json(popularCourses);
});

// Get categories
app.get('/api/categories', (req, res) => {
    console.log('📂 Fetching categories');
    const categories = [...new Set(sampleCourses.map(course => course.category))];
    res.json(categories);
});

// Get single course by ID
app.get('/api/courses/:id', (req, res) => {
    try {
        const courseId = parseInt(req.params.id);
        console.log('🔍 Looking for course ID:', courseId, 'Type:', typeof courseId);
        
        // Check if courseId is a valid number
        if (isNaN(courseId)) {
            console.log('❌ Invalid course ID:', req.params.id);
            return res.status(400).json({
                success: false,
                error: 'Invalid course ID'
            });
        }
        
        const course = sampleCourses.find(c => c.id === courseId);
        
        if (!course) {
            console.log('❌ Course not found for ID:', courseId);
            return res.status(404).json({
                success: false,
                error: 'Course not found'
            });
        }
        
        console.log('✅ Course found:', course.title);
        res.json(course);
        
    } catch (error) {
        console.error('💥 Course details error:', error);
        res.status(500).json({
            success: false,
            error: 'Internal server error'
        });
    }
});

// ==================== USER PROGRESS ENDPOINTS ====================

// User progress - ab user-specific hoga
app.get('/api/user/progress', (req, res) => {
    try {
        // Frontend se user ID milega
        const userId = parseInt(req.query.userId) || 1;
        console.log('📊 Fetching progress for user:', userId);
        
        // User ke enrollments find karo
        const userEnrollments = enrollments.filter(e => e.userId === userId);
        
        // Completed courses count karo
        const completedCourses = userEnrollments.filter(e => e.completed).length;
        
        // Total learning time calculate karo (demo calculation)
        const totalHours = userEnrollments.reduce((total, enrollment) => {
            const course = sampleCourses.find(c => c.id === enrollment.courseId);
            return total + (parseInt(course?.duration?.split(' ')[0]) || 0);
        }, 0);
        
        // Current streak calculate karo (demo logic)
        const currentStreak = userEnrollments.length > 0 ? Math.floor(Math.random() * 10) + 1 : 0;
        
        // In progress courses (not completed but progress > 0)
        const inProgressCourses = userEnrollments.filter(e => !e.completed && e.progress > 0).length;

          const notStartedCourses = userEnrollments.filter(e => e.progress === 0).length;
        
         const progressData = {
            enrolled_courses: userEnrollments.length,
            completed_courses: completedCourses,
            learning_time: totalHours > 24 
                ? `${Math.floor(totalHours / 24)}d ${totalHours % 24}h` 
                : `${totalHours}h 0m`,
            current_streak: currentStreak,
            total_enrollments: userEnrollments.length,
            in_progress_courses: inProgressCourses,
            not_started_courses: notStartedCourses
        };
        
        console.log('✅ User progress data for user', userId, ':', progressData);
        res.json(progressData);
        
    } catch (error) {
        console.error('💥 User progress error:', error);
        res.status(500).json({
            success: false,
            error: 'Internal server error'
        });
    }
});

// ==================== DEMO PAYMENT ENDPOINTS ====================

// Demo payment intent
app.post('/api/create-payment-intent', async (req, res) => {
    try {
        const { courseId, amount, userId } = req.body;
        
        console.log('💳 Demo payment intent for course:', courseId, 'User:', userId, 'Amount:', amount);

        // Demo payment intent
        const demoPaymentIntent = {
            id: 'demo_pi_' + Date.now(),
            client_secret: 'demo_secret_' + Date.now(),
            status: 'requires_payment_method'
        };

        console.log('✅ Demo payment intent created:', demoPaymentIntent.id);

        res.json({
            success: true,
            clientSecret: demoPaymentIntent.client_secret,
            paymentIntentId: demoPaymentIntent.id
        });

    } catch (error) {
        console.error('💥 Payment intent error:', error);
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// Handle successful payment - ab user-specific enrollment create hoga
app.post('/api/payment-success', async (req, res) => {
    try {
        const { paymentIntentId, courseId, userId } = req.body;
        
        console.log('🎉 Demo payment successful:', {
            paymentIntentId,
            courseId,
            userId
        });

        // Check if user already enrolled in this course
        const existingEnrollment = enrollments.find(
            e => e.userId === parseInt(userId) && e.courseId === parseInt(courseId)
        );

         if (existingEnrollment) {
            return res.status(400).json({
                success: false,
                error: 'User already enrolled in this course'
            });
        }

        // Create new enrollment for specific user
        const enrollment = {
            id: `enroll_${Date.now()}`,
            userId: parseInt(userId),
            courseId: parseInt(courseId),
            paymentIntentId: paymentIntentId,
            enrolledAt: new Date().toISOString(),
            status: 'active',
            progress: 0,
            completed: false
        };
        enrollments.push(enrollment);

        console.log('✅ New enrollment created for user:', userId, 'Course:', courseId);

         res.json({
            success: true,
            message: 'Payment successful! Course enrolled successfully.',
            enrollmentId: enrollment.id,
            courseId: courseId,
            userId: userId,
            enrollment: enrollment
        });

     } catch (error) {
        console.error('💥 Payment success handling error:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to process enrollment'
        });
    }
});

// Get user enrollments - specific user ke liye
app.get('/api/user/enrollments', (req, res) => {
    try {
        const userId = parseInt(req.query.userId) || 1;
        console.log('📋 Fetching enrollments for user:', userId);
        
        const userEnrollments = enrollments.filter(e => e.userId === userId);
        
        const enrolledCourses = userEnrollments.map(enrollment => {
            const course = sampleCourses.find(c => c.id === enrollment.courseId);
            return {
                ...enrollment,
                course: course
            };
        });

        console.log('✅ User enrollments count:', enrolledCourses.length);
        res.json({
            success: true,
            enrollments: enrolledCourses
        });

    } catch (error) {
        console.error('💥 User enrollments error:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to fetch enrollments'
        });
    }
});

// Mark course as completed
app.post('/api/user/complete-course', (req, res) => {
    try {
        const { userId, courseId } = req.body;
        
        console.log('🎓 Marking course as completed:', { userId, courseId });
        
        const enrollment = enrollments.find(
            e => e.userId === parseInt(userId) && e.courseId === parseInt(courseId)
        );
        
        if (!enrollment) {
            return res.status(404).json({
                success: false,
                error: 'Enrollment not found'
            });
        }
        
        enrollment.completed = true;
        enrollment.progress = 100;
        enrollment.completedAt = new Date().toISOString();
        
        console.log('✅ Course marked as completed');
        
        res.json({
            success: true,
            message: 'Course completed successfully!',
            enrollment: enrollment
        });
        
    } catch (error) {
        console.error('💥 Complete course error:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to mark course as completed'
        });
    }
});

// Update course progress
app.post('/api/user/update-progress', (req, res) => {
    try {
        const { userId, courseId, progress } = req.body;
        
        console.log('📈 Updating course progress:', { userId, courseId, progress });
        
        const enrollment = enrollments.find(
            e => e.userId === parseInt(userId) && e.courseId === parseInt(courseId)
        );
        
        if (!enrollment) {
            return res.status(404).json({
                success: false,
                error: 'Enrollment not found'
            });
        }
        
        enrollment.progress = Math.min(100, Math.max(0, parseInt(progress)));
        
        if (enrollment.progress === 100) {
            enrollment.completed = true;
            enrollment.completedAt = new Date().toISOString();
        }
        
        console.log('✅ Progress updated to:', enrollment.progress);
        
        res.json({
            success: true,
            message: 'Progress updated successfully',
            enrollment: enrollment
        });
        
    } catch (error) {
        console.error('💥 Update progress error:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to update progress'
        });
    }
});

// Verify payment status
app.get('/api/payment-status/:paymentIntentId', async (req, res) => {
    try {
        const { paymentIntentId } = req.params;
        
        // Demo payment status
        res.json({
            success: true,
            status: 'succeeded',
            amount: 49.99,
            courseId: 1
        });

    } catch (error) {
        console.error('💥 Payment status error:', error);
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// Health check endpoint
app.get('/api/health', (req, res) => {
    res.json({
        success: true,
        message: 'Server is running',
        timestamp: new Date().toISOString(),
        courses: sampleCourses.length,
        users: users.length,
        enrollments: enrollments.length
    });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
    console.log(`🚀 Server running on http://localhost:${PORT}`);
    console.log(`📊 Initial users: ${users.length}`);
    console.log(`📚 Total courses: ${sampleCourses.length}`);
    console.log(`📋 Total enrollments: ${enrollments.length}`);
    console.log(`🔗 CORS enabled for: http://localhost:3000`);
    console.log(`💳 Demo payment system ready`);
    console.log(`👤 User-specific progress system ready`);
});